const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChatMessage {
  role: "user" | "model";
  text: string;
}

const SYSTEM_PROMPT = `أنت "المُسْتَشَارُ الدَّوَادِيُّ الذَّكِيُّ"، مساعد ذكاء اصطناعي متخصص في مساعدة طلاب الثانوية العامة المصرية. مهمتك:

1. شرح الدروس والمفاهيم بأسلوب بسيط وواضح
2. حل المسائل خطوة بخطوة
3. تقديم نصائح للمذاكرة والاستعداد للامتحانات
4. الإجابة على أسئلة المواد: الفيزياء، الكيمياء، الأحياء، الرياضيات، اللغة العربية، اللغة الإنجليزية، التاريخ، الجغرافيا، الفلسفة والمنطق، علم النفس والاجتماع

قواعد الإجابة:
- اجب باللغة العربية دائماً
- كن ودوداً ومشجعاً
- استخدم الأمثلة التوضيحية عند الشرح
- قسّم الإجابات الطويلة إلى نقاط واضحة
- إذا لم تفهم السؤال، اطلب التوضيح
- تذكر محادثتك السابقة مع الطالب وارجع إليها عند الحاجة
- إذا طلب الطالب توضيحاً، اشرح بطريقة مختلفة وأبسط`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { messages } = await req.json() as { messages: ChatMessage[] };

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return new Response(
        JSON.stringify({ error: "messages array is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const geminiApiKey = "AQ.Ab8RN6KTmH7h_mSL2oEkX_z2_lLsEiVbblB-uR7SbR6Nco28tw";

    // Build Gemini contents with full conversation history
    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
    for (const m of messages) {
      contents.push({ role: m.role, parts: [{ text: m.text }] });
    }

    const geminiPayload = {
      system_instruction: {
        parts: [{ text: SYSTEM_PROMPT }],
      },
      contents,
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024,
      },
    };

    // Try multiple models — 3.5-flash first (fast & reliable), then 3.8-flash
    // Models are tried in order; first success returns immediately.
    const models = ["gemini-3.5-flash", "gemini-3.8-flash"];
    let lastError = "";

    for (const model of models) {
      const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiApiKey}`;

      const geminiResponse = await fetch(geminiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(geminiPayload),
      });

      if (geminiResponse.ok) {
        const geminiData = await geminiResponse.json();
        const reply = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (reply && reply.length > 0) {
          return new Response(
            JSON.stringify({ reply }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        lastError = "Empty response from " + model;
      } else {
        lastError = await geminiResponse.text();
        console.error(`Model ${model} error:`, lastError);
      }
    }

    console.error("All Gemini models failed. Last error:", lastError);
    return new Response(
      JSON.stringify({ error: "GEMINI_API_ERROR", reply: "" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Edge function error:", err);
    return new Response(
      JSON.stringify({ error: "INTERNAL_ERROR", reply: "" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
