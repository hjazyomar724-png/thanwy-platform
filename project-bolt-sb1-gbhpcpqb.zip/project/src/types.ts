export type ThemeKey = 'normal' | 'ramadan' | 'october' | 'eid_fitr' | 'eid_adha';

export interface AdSlotConfig {
  header: string;
  sidebar: string;
  belowContent: string;
}

export interface AdminSettings {
  adsEnabled: boolean;
  adCodes: AdSlotConfig;
  seasonalTheme: ThemeKey;
}

export const DEFAULT_SETTINGS: AdminSettings = {
  adsEnabled: false,
  adCodes: {
    header: '',
    sidebar: '',
    belowContent: '',
  },
  seasonalTheme: 'normal',
};

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  lessons: number;
  description: string;
}

export interface QuizQuestion {
  id: string;
  subject: string;
  question: string;
  choices: [string, string, string, string];
  correctIndex: number;
  difficulty: 'سهل' | 'متوسط' | 'صعب';
}

export interface LibraryBook {
  id: string;
  title: string;
  subject: string;
  type: 'ملخص' | 'كتاب وزارة' | 'مفاهيم';
  link: string;
}

export interface ErrorReport {
  id: string;
  targetType: 'سؤال' | 'كتاب' | 'أخرى';
  targetTitle: string;
  message: string;
  studentName: string;
  status: 'جديد' | 'تم المراجعة';
  createdAt: number;
}

export interface Comment {
  id: string;
  author: string;
  text: string;
  createdAt: number;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  author: string;
  createdAt: number;
  likes: number;
  liked: boolean;
  comments: Comment[];
}
