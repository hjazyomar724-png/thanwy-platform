import type { Subject } from '@/types';

export const subjects: Subject[] = [
  {
    id: 'arabic',
    name: 'اللغة العربية',
    icon: 'BookOpen',
    color: '#0E7490',
    lessons: 24,
    description: 'نحو، بلاغة، أدب، نصوص',
  },
  {
    id: 'english',
    name: 'اللغة الإنجليزية',
    icon: 'Globe',
    color: '#7C3AED',
    lessons: 20,
    description: 'Grammar, Reading, Writing',
  },
  {
    id: 'math',
    name: 'الرياضيات',
    icon: 'Sigma',
    color: '#0891B2',
    lessons: 18,
    description: 'جبر، هندسة، تفاضل وتكامل',
  },
  {
    id: 'physics',
    name: 'الفيزياء',
    icon: 'Atom',
    color: '#DC2626',
    lessons: 22,
    description: 'ميكانيكا، كهربية، فيزياء حديثة',
  },
  {
    id: 'chemistry',
    name: 'الكيمياء',
    icon: 'FlaskConical',
    color: '#EA580C',
    lessons: 20,
    description: 'كيمياء عضوية وغير عضوية',
  },
  {
    id: 'biology',
    name: 'الأحياء',
    icon: 'Dna',
    color: '#16A34A',
    lessons: 19,
    description: 'خلية، وراثة، بيئة',
  },
  {
    id: 'history',
    name: 'التاريخ',
    icon: 'ScrollText',
    color: '#B45309',
    lessons: 15,
    description: 'تاريخ مصر الحديث والمعاصر',
  },
  {
    id: 'geography',
    name: 'الجغرافيا',
    icon: 'MapPinned',
    color: '#0D9488',
    lessons: 14,
    description: 'جغرافيا طبيعية واقتصادية',
  },
  {
    id: 'philosophy',
    name: 'الفلسفة والمنطق',
    icon: 'Brain',
    color: '#9333EA',
    lessons: 12,
    description: 'فلسفة، منطق، مدارس فكرية',
  },
  {
    id: 'psychology',
    name: 'علم النفس والاجتماع',
    icon: 'HeartHandshake',
    color: '#DB2777',
    lessons: 12,
    description: 'علم النفس، علم الاجتماع',
  },
];

export const stats = [
  { label: 'مادة دراسية', value: '10+', icon: 'BookOpenText' },
  { label: 'درس ملخص', value: '180+', icon: 'FileText' },
  { label: 'امتحان حللى', value: '50+', icon: 'ClipboardCheck' },
  { label: 'طالب نشط', value: '5K+', icon: 'Users' },
];

export const features = [
  {
    title: 'ملخصات شاملة',
    description: 'ملخصات لكل مادة من مواد الثانوية العامة، مرتبة ومنظمة تساعدك على المراجعة السريعة.',
    icon: 'Sparkles',
  },
  {
    title: 'امتحانات تفاعلية',
    description: 'حل امتحانات حقيقية مع تصحيح فوري وعرض النموذج الإجابة بعد الانتهاء.',
    icon: 'ClipboardCheck',
  },
  {
    title: 'فيديوهات شرح',
    description: 'مكتبة فيديوهات شرح لكل درس من أفضل المعلمين على مستوى الجمهورية.',
    icon: 'PlayCircle',
  },
  {
    title: 'جدول مذاكرة',
    description: 'نظّم وقتك مع جدول مذاكرة ذكي يتكيف مع موعد امتحاناتك ومستواك.',
    icon: 'CalendarDays',
  },
];
