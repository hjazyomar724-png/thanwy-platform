import { CalendarDays, Clock, BookOpen, Plus } from 'lucide-react';
import AdSlot from '@/components/AdSlot';

const schedule = [
  { day: 'السبت', slots: [{ time: '9:00 - 11:00', subject: 'اللغة العربية', color: '#0E7490' }, { time: '11:30 - 1:30', subject: 'الرياضيات', color: '#0891B2' }] },
  { day: 'الأحد', slots: [{ time: '9:00 - 11:00', subject: 'الفيزياء', color: '#DC2626' }, { time: '11:30 - 1:30', subject: 'الكيمياء', color: '#EA580C' }] },
  { day: 'الإثنين', slots: [{ time: '9:00 - 11:00', subject: 'اللغة الإنجليزية', color: '#7C3AED' }, { time: '11:30 - 1:30', subject: 'الأحياء', color: '#16A34A' }] },
  { day: 'الثلاثاء', slots: [{ time: '9:00 - 11:00', subject: 'اللغة العربية', color: '#0E7490' }, { time: '11:30 - 1:30', subject: 'الرياضيات', color: '#0891B2' }] },
  { day: 'الأربعاء', slots: [{ time: '9:00 - 11:00', subject: 'الفيزياء', color: '#DC2626' }, { time: '11:30 - 1:30', subject: 'التاريخ', color: '#B45309' }] },
  { day: 'الخميس', slots: [{ time: '9:00 - 11:00', subject: 'اللغة الإنجليزية', color: '#7C3AED' }, { time: '11:30 - 1:30', subject: 'الفلسفة', color: '#9333EA' }] },
];

export default function SchedulePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-3">جدول المذاكرة</h1>
        <p className="text-slate-500">نظّم وقتك وذاكر بذكاء</p>
      </div>

      <AdSlot slot="header" />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
        {schedule.map((day, i) => (
          <div key={i} className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition">
            <div className="bg-gradient-to-r from-cyan-600 to-blue-700 text-white px-5 py-3 flex items-center gap-2">
              <CalendarDays className="w-5 h-5" />
              <span className="font-bold">{day.day}</span>
            </div>
            <div className="p-4 space-y-3">
              {day.slots.map((slot, j) => (
                <div key={j} className="flex items-center gap-3 p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition">
                  <div className="w-1 h-10 rounded-full" style={{ backgroundColor: slot.color }} />
                  <div className="flex-1">
                    <div className="font-medium text-sm text-slate-800">{slot.subject}</div>
                    <div className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      {slot.time}
                    </div>
                  </div>
                  <BookOpen className="w-4 h-4 text-slate-300" />
                </div>
              ))}
              <button className="w-full flex items-center justify-center gap-1 text-xs text-slate-400 hover:text-cyan-600 transition py-2">
                <Plus className="w-4 h-4" />
                إضافة حصة
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <AdSlot slot="belowContent" />
      </div>
    </div>
  );
}
