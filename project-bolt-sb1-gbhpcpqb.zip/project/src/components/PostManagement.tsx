import { useState } from 'react';
import {
  Plus, Trash2, Pencil, X, Save, Newspaper, CheckCircle2, Clock,
} from 'lucide-react';
import { useContent } from '@/context/ContentContext';
import type { Post } from '@/types';

const emptyForm = {
  title: '',
  content: '',
};

function formatDate(ts: number): string {
  return new Date(ts).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function PostManagement() {
  const { posts, addPost, updatePost, deletePost } = useContent();
  const [form, setForm] = useState({ ...emptyForm });
  const [published, setPublished] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<typeof emptyForm | null>(null);
  const [savedEdit, setSavedEdit] = useState(false);

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim() || !form.content.trim()) return;

    addPost({
      id: `p-${Date.now()}`,
      title: form.title.trim(),
      content: form.content.trim(),
      author: 'إدارة المنصة',
      createdAt: Date.now(),
      likes: 0,
      liked: false,
      comments: [],
    });

    setForm({ ...emptyForm });
    setPublished(true);
    setTimeout(() => setPublished(false), 2500);
  };

  const startEdit = (p: Post) => {
    setEditingId(p.id);
    setEditForm({ title: p.title, content: p.content });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm(null);
  };

  const saveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm || !editingId || !editForm.title.trim() || !editForm.content.trim()) return;

    updatePost({
      ...posts.find((p) => p.id === editingId)!,
      title: editForm.title.trim(),
      content: editForm.content.trim(),
    });

    cancelEdit();
    setSavedEdit(true);
    setTimeout(() => setSavedEdit(false), 2500);
  };

  return (
    <div className="space-y-6">
      {published && (
        <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg px-4 py-3 animate-fade-in-up">
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-medium">تم نشر المنشور بنجاح! يظهر الآن فوراً في ساحة المنشورات.</span>
        </div>
      )}

      {savedEdit && (
        <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg px-4 py-3 animate-fade-in-up">
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-medium">تم حفظ التعديلات بنجاح! تم تحديث المنشور في الساحة.</span>
        </div>
      )}

      {/* Publish form */}
      <form onSubmit={handlePublish} className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Plus className="w-5 h-5 text-cyan-600" />
          <h3 className="font-bold text-slate-800">نشر منشور / خبر جديد</h3>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">عنوان المنشور</label>
          <input
            type="text"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="مثال: جدول امتحانات الشهر التجريبية"
            className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">محتوى المنشور</label>
          <textarea
            value={form.content}
            onChange={(e) => setForm({ ...form, content: e.target.value })}
            rows={5}
            placeholder="اكتب محتوى المنشور هنا..."
            className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800 resize-none"
          />
        </div>

        <button
          type="submit"
          className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold px-6 py-3 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg"
        >
          <Newspaper className="w-5 h-5" />
          نشر الآن
        </button>
      </form>

      {/* Existing posts */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Newspaper className="w-5 h-5 text-slate-600" />
          <h3 className="font-bold text-slate-800">المنشورات المنشورة ({posts.length})</h3>
        </div>
        {posts.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-6">لا توجد منشورات بعد</p>
        ) : (
          <div className="space-y-3">
            {posts.map((post) => (
              <div key={post.id} className="rounded-lg bg-slate-50 border border-slate-100 overflow-hidden">
                {/* Post row */}
                <div className="flex items-start gap-3 p-3">
                  <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                    <Newspaper className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-800 truncate">{post.title}</p>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{post.content}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="flex items-center gap-1 text-xs text-slate-400">
                        <Clock className="w-3 h-3" />
                        {formatDate(post.createdAt)}
                      </span>
                      <span className="text-xs text-slate-400">{post.likes} إعجاب</span>
                      <span className="text-xs text-slate-400">{post.comments.length} تعليق</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={() => startEdit(post)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-cyan-600 hover:bg-cyan-50 transition text-xs font-medium"
                    >
                      <Pencil className="w-4 h-4" />
                      تعديل
                    </button>
                    <button
                      onClick={() => deletePost(post.id)}
                      className="flex-shrink-0 p-1.5 rounded-lg text-red-400 hover:bg-red-50 hover:text-red-600 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Inline edit form */}
                {editingId === post.id && editForm && (
                  <form
                    onSubmit={saveEdit}
                    className="border-t border-slate-200 bg-white p-4 space-y-3 animate-fade-in-up"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-bold text-slate-700">تعديل المنشور</span>
                      <button
                        type="button"
                        onClick={cancelEdit}
                        className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 transition"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">عنوان المنشور</label>
                      <input
                        type="text"
                        value={editForm.title}
                        onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">محتوى المنشور</label>
                      <textarea
                        value={editForm.content}
                        onChange={(e) => setEditForm({ ...editForm, content: e.target.value })}
                        rows={4}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800 resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold px-5 py-2.5 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg text-sm"
                    >
                      <Save className="w-4 h-4" />
                      حفظ التعديلات
                    </button>
                  </form>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
