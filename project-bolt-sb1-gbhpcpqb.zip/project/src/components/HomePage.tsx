import {
  BookOpen, Globe, Sigma, Atom, FlaskConical, Dna, ScrollText, MapPinned,
  Brain, HeartHandshake, Sparkles, ClipboardCheck, PlayCircle, CalendarDays,
  ArrowLeft, BookOpenText, FileText, Users, type LucideIcon,
} from 'lucide-react';
import { subjects, stats, features } from '@/data';
import AdSlot from '@/components/AdSlot';

const iconMap: Record<string, LucideIcon> = {
  BookOpen, Globe, Sigma, Atom, FlaskConical, Dna, ScrollText, MapPinned,
  Brain, HeartHandshake, Sparkles, ClipboardCheck, PlayCircle, CalendarDays,
  BookOpenText, FileText, Users,
};

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="animate-fade-in-up">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-cyan-600 via-blue-700 to-indigo-800 text-white">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, white 2px, transparent 2px), radial-gradient(circle at 80% 20%, white 2px, transparent 2px)',
          backgroundSize: '50px 50px',
        }} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur rounded-full px-4 py-1.5 mb-6 border border-white/20">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span className="text-sm font-medium">منصة تعليمية مجانية لطلاب الثانوية العامة</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight">
              رحلتك نحو التفوق تبدأ هنا
            </h1>
            <p className="text-lg sm:text-xl text-blue-100 mb-8 leading-relaxed">
              ملخصات شاملة، امتحانات تفاعلية، فيديوهات شرح، وجدول مذاكرة ذكي — كل ما تحتاجه في مكان واحد
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('subjects')}
                className="flex items-center justify-center gap-2 bg-white text-cyan-700 font-bold px-8 py-3.5 rounded-xl hover:bg-blue-50 transition shadow-lg hover:shadow-xl"
              >
                ابدأ المذاكرة الآن
                <ArrowLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => onNavigate('studyhub')}
                className="flex items-center justify-center gap-2 bg-white/10 backdrop-blur border border-white/30 text-white font-bold px-8 py-3.5 rounded-xl hover:bg-white/20 transition"
              >
                <ClipboardCheck className="w-5 h-5" />
                تصفح الملخصات
              </button>
            </div>
          </div>
        </div>
        {/* Wave bottom */}
        <svg className="absolute bottom-0 left-0 right-0 w-full" viewBox="0 0 1440 80" preserveAspectRatio="none">
          <path d="M0,40 C360,80 720,0 1440,40 L1440,80 L0,80 Z" fill="#f8fafc" />
        </svg>
      </section>

      {/* Header Ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
        <AdSlot slot="header" />
      </div>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, i) => {
            const Icon = iconMap[stat.icon];
            return (
              <div
                key={i}
                className="bg-white rounded-xl border border-slate-200 p-5 text-center hover:shadow-lg transition-all hover:-translate-y-1"
              >
                <div className="inline-flex p-3 bg-cyan-50 rounded-xl mb-3">
                  {Icon && <Icon className="w-6 h-6 text-cyan-600" />}
                </div>
                <div className="text-3xl font-extrabold text-slate-800">{stat.value}</div>
                <div className="text-sm text-slate-500 mt-1">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-slate-800 mb-3">لماذا منصتنا؟</h2>
          <p className="text-slate-500">كل ما يحتاجه طالب الثانوية العامة في مكان واحد</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => {
            const Icon = iconMap[feature.icon];
            return (
              <div
                key={i}
                className="bg-white rounded-xl border border-slate-200 p-6 hover:shadow-xl transition-all hover:-translate-y-1 group"
              >
                <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-3 rounded-xl mb-4 inline-block group-hover:scale-110 transition">
                  {Icon && <Icon className="w-7 h-7 text-white" />}
                </div>
                <h3 className="font-bold text-lg text-slate-800 mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Quick access: Study Hub + Exams */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <button
            onClick={() => onNavigate('studyhub')}
            className="group bg-gradient-to-br from-cyan-50 to-blue-50 border border-cyan-200 rounded-2xl p-6 text-right hover:shadow-xl transition-all hover:-translate-y-1"
          >
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-3 rounded-xl group-hover:scale-110 transition">
                <BookOpenText className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-slate-800">مركز الملخصات والكتب</h3>
                <p className="text-sm text-slate-500 mt-0.5">كتب الوزارة، مجلدات المفاهيم، وملخصات شاملة</p>
              </div>
              <ArrowLeft className="w-5 h-5 text-cyan-600 group-hover:-translate-x-1 transition" />
            </div>
          </button>
          <button
            onClick={() => onNavigate('exams')}
            className="group bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-6 text-right hover:shadow-xl transition-all hover:-translate-y-1"
          >
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-3 rounded-xl group-hover:scale-110 transition">
                <ClipboardCheck className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-slate-800">مركز الامتحانات</h3>
                <p className="text-sm text-slate-500 mt-0.5">امتحانات تفاعلية مع تصحيح فوري وعرض النتيجة</p>
              </div>
              <ArrowLeft className="w-5 h-5 text-amber-600 group-hover:-translate-x-1 transition" />
            </div>
          </button>
        </div>
      </section>

      {/* Subjects preview with sidebar ad */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold text-slate-800">المواد الدراسية</h2>
              <button
                onClick={() => onNavigate('subjects')}
                className="text-cyan-600 hover:text-cyan-700 text-sm font-medium flex items-center gap-1"
              >
                عرض الكل
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {subjects.slice(0, 4).map((subject) => {
                const Icon = iconMap[subject.icon];
                return (
                  <div
                    key={subject.id}
                    onClick={() => onNavigate('subjects')}
                    className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-4 cursor-pointer hover:shadow-lg hover:border-cyan-300 transition-all group"
                  >
                    <div
                      className="p-3 rounded-xl flex-shrink-0 group-hover:scale-110 transition"
                      style={{ backgroundColor: subject.color + '15' }}
                    >
                      {Icon && <Icon className="w-8 h-8" style={{ color: subject.color }} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-slate-800 truncate">{subject.name}</h3>
                      <p className="text-xs text-slate-500 mt-0.5 truncate">{subject.description}</p>
                      <span className="text-xs text-slate-400">{subject.lessons} درس</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          {/* Sidebar ad */}
          <div className="lg:w-64 flex-shrink-0">
            <AdSlot slot="sidebar" />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-gradient-to-r from-cyan-600 to-blue-700 rounded-2xl p-8 sm:p-12 text-center text-white relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-3xl font-bold mb-3">جاهز للتفوق؟</h2>
            <p className="text-blue-100 mb-6 max-w-xl mx-auto">
              انضم لآلاف الطلاب الذين يذاكرون على منصتنا واحصل على أفضل النتائج
            </p>
            <button
              onClick={() => onNavigate('subjects')}
              className="bg-white text-cyan-700 font-bold px-8 py-3.5 rounded-xl hover:bg-blue-50 transition shadow-lg inline-flex items-center gap-2"
            >
              ابدأ الآن مجاناً
              <ArrowLeft className="w-5 h-5" />
            </button>
          </div>
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full" />
          <div className="absolute -bottom-10 -left-10 w-52 h-52 bg-white/10 rounded-full" />
        </div>
      </section>

      {/* Below content ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <AdSlot slot="belowContent" />
      </div>
    </div>
  );
}
