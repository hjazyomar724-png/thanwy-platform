import { GraduationCap, Menu, X, Shield, Sparkles } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

const navLinks = [
  { id: 'home', label: 'الرئيسية' },
  { id: 'subjects', label: 'المواد الدراسية' },
  { id: 'studyhub', label: 'مركز الملخصات' },
  { id: 'exams', label: 'الامتحانات' },
  { id: 'feed', label: 'ساحة المنشورات' },
  { id: 'ai', label: 'المستشار الذكي' },
  { id: 'schedule', label: 'جدول المذاكرة' },
  { id: 'about', label: 'من نحن' },
];

export default function Header({ onNavigate, currentPage }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <div className="bg-gradient-to-br from-cyan-600 to-blue-700 p-2 rounded-xl">
              <GraduationCap className="w-7 h-7 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold text-slate-800 leading-tight">منصة الطالب المصري</span>
              <span className="text-xs text-slate-500">الثانوية العامة</span>
            </div>
          </div>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-1 ${
                  currentPage === link.id
                    ? 'bg-cyan-50 text-cyan-700'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                {link.id === 'ai' && <Sparkles className="w-3.5 h-3.5" />}
                {link.label}
              </button>
            ))}
          </nav>

          {/* Admin button + mobile toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('admin')}
              className={`p-2 rounded-lg transition-all duration-200 ${
                currentPage === 'admin'
                  ? 'bg-cyan-50 text-cyan-700'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
              title="الإدارة"
            >
              <Shield className="w-5 h-5" />
            </button>
            <span className="hidden lg:inline text-sm font-medium text-slate-400">الإدارة</span>
            <button
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <nav className="lg:hidden py-3 border-t border-slate-200 animate-fade-in-up">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setMobileOpen(false);
                }}
                className={`w-full text-right px-4 py-3 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                  currentPage === link.id
                    ? 'bg-cyan-50 text-cyan-700'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {link.id === 'ai' && <Sparkles className="w-4 h-4" />}
                {link.label}
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
