import { useState } from 'react';
import {
  LayoutDashboard, Megaphone, Palette, LogOut, Sparkles,
  ClipboardList, Library, Flag, Newspaper,
} from 'lucide-react';
import AdsManagement from '@/components/AdsManagement';
import SeasonalThemesSection from '@/components/SeasonalThemesSection';
import QuizManagement from '@/components/QuizManagement';
import LibraryManagement from '@/components/LibraryManagement';
import ReportsManagement from '@/components/ReportsManagement';
import PostManagement from '@/components/PostManagement';
import { useContent } from '@/context/ContentContext';

interface AdminPanelProps {
  onLogout: () => void;
}

type Tab = 'ads' | 'themes' | 'quizzes' | 'library' | 'reports' | 'posts';

export default function AdminPanel({ onLogout }: AdminPanelProps) {
  const [tab, setTab] = useState<Tab>('ads');
  const { reports } = useContent();
  const newReports = reports.filter((r) => r.status === 'جديد').length;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-3 rounded-xl">
            <LayoutDashboard className="w-7 h-7 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">لوحة تحكم المدير</h2>
            <p className="text-sm text-slate-500">إدارة إعدادات ومحتوى المنصة</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition font-medium text-sm"
        >
          <LogOut className="w-4 h-4" />
          خروج
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 border-b border-slate-200 overflow-x-auto">
        <TabButton active={tab === 'ads'} onClick={() => setTab('ads')} icon={Megaphone} label="الإعلانات" />
        <TabButton active={tab === 'themes'} onClick={() => setTab('themes')} icon={Palette} label="الزينة والمناسبات" />
        <TabButton active={tab === 'quizzes'} onClick={() => setTab('quizzes')} icon={ClipboardList} label="إدارة الامتحانات" />
        <TabButton active={tab === 'library'} onClick={() => setTab('library')} icon={Library} label="إدارة الكتب" />
        <TabButton
          active={tab === 'reports'}
          onClick={() => setTab('reports')}
          icon={Flag}
          label="بلاغات الطلاب"
          badge={newReports}
        />
        <TabButton
          active={tab === 'posts'}
          onClick={() => setTab('posts')}
          icon={Newspaper}
          label="إدارة المنشورات"
        />
      </div>

      {/* Content */}
      <div className="animate-fade-in-up">
        {tab === 'ads' && <AdsManagement />}
        {tab === 'themes' && <SeasonalThemesSection />}
        {tab === 'quizzes' && <QuizManagement />}
        {tab === 'library' && <LibraryManagement />}
        {tab === 'reports' && <ReportsManagement />}
        {tab === 'posts' && <PostManagement />}
      </div>

      {/* Note */}
      <div className="mt-8 flex items-center gap-2 text-xs text-slate-400 bg-slate-50 rounded-lg px-4 py-3">
        <Sparkles className="w-4 h-4" />
        <span>يتم حفظ جميع الإعدادات والمحتوى تلقائياً وتطبيقها فوراً على المنصة.</span>
      </div>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon: Icon,
  label,
  badge,
}: {
  active: boolean;
  onClick: () => void;
  icon: typeof Megaphone;
  label: string;
  badge?: number;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-3 font-medium text-sm transition-all border-b-2 -mb-px whitespace-nowrap ${
        active
          ? 'border-cyan-600 text-cyan-700'
          : 'border-transparent text-slate-500 hover:text-slate-700'
      }`}
    >
      <Icon className="w-4 h-4" />
      {label}
      {badge !== undefined && badge > 0 && (
        <span className="bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full leading-none">
          {badge}
        </span>
      )}
    </button>
  );
}
