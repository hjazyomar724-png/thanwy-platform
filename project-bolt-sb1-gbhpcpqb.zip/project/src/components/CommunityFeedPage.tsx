import { useState } from 'react';
import {
  Newspaper, ThumbsUp, MessageCircle, Send, Clock, Pin,
} from 'lucide-react';
import { useContent } from '@/context/ContentContext';
import AdSlot from '@/components/AdSlot';
import type { Comment } from '@/types';

function formatDate(ts: number): string {
  const d = new Date(ts);
  const now = Date.now();
  const diff = now - ts;
  if (diff < 3600000) return `منذ ${Math.floor(diff / 60000)} دقيقة`;
  if (diff < 86400000) return `منذ ${Math.floor(diff / 3600000)} ساعة`;
  if (diff < 604800000) return `منذ ${Math.floor(diff / 86400000)} يوم`;
  return d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long' });
}

export default function CommunityFeedPage() {
  const { posts, toggleLike, addComment } = useContent();
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());

  const toggleComments = (id: string) => {
    setExpandedComments((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleComment = (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    const comment: Comment = {
      id: `c-${Date.now()}`,
      author: 'طالب',
      text,
      createdAt: Date.now(),
    };
    addComment(postId, comment);
    setCommentInputs({ ...commentInputs, [postId]: '' });
    setExpandedComments((prev) => new Set(prev).add(postId));
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
      <div className="text-center mb-8">
        <div className="inline-flex bg-gradient-to-br from-cyan-500 to-blue-600 p-3 rounded-2xl mb-4">
          <Newspaper className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-3">ساحة المنشورات والأخبار التعليمية</h1>
        <p className="text-slate-500">آخر الأخبار والإعلانات من إدارة المنصة</p>
      </div>

      <AdSlot slot="header" />

      {/* Posts timeline */}
      <div className="mt-8 space-y-6">
        {posts.length === 0 ? (
          <div className="text-center py-16">
            <Newspaper className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-400">لا توجد منشورات حالياً</p>
          </div>
        ) : (
          posts.map((post, idx) => (
            <div key={post.id} className="relative">
              {/* Timeline dot + line */}
              {idx < posts.length - 1 && (
                <div className="absolute right-[22px] top-16 bottom-0 w-0.5 bg-slate-200" />
              )}

              <div className="flex gap-4">
                {/* Timeline dot */}
                <div className="flex-shrink-0 w-11 h-11 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center z-10">
                  <Pin className="w-5 h-5 text-white" />
                </div>

                {/* Post card */}
                <div className="flex-1 bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-lg transition">
                  {/* Post header */}
                  <div className="p-5 pb-3">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-100 to-blue-100 flex items-center justify-center text-xs font-bold text-cyan-700">
                        إدارة
                      </div>
                      <span className="font-bold text-sm text-slate-800">{post.author}</span>
                      <span className="flex items-center gap-1 text-xs text-slate-400 mr-auto">
                        <Clock className="w-3 h-3" />
                        {formatDate(post.createdAt)}
                      </span>
                    </div>
                    <h3 className="font-bold text-lg text-slate-800 mb-2">{post.title}</h3>
                    <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line">{post.content}</p>
                  </div>

                  {/* Post actions */}
                  <div className="px-5 py-3 border-t border-slate-100 flex items-center gap-4">
                    <button
                      onClick={() => toggleLike(post.id)}
                      className={`flex items-center gap-1.5 text-sm font-medium transition ${
                        post.liked
                          ? 'text-cyan-600'
                          : 'text-slate-500 hover:text-cyan-600'
                      }`}
                    >
                      <ThumbsUp className={`w-4 h-4 ${post.liked ? 'fill-cyan-600' : ''}`} />
                      {post.likes} إعجاب
                    </button>
                    <button
                      onClick={() => toggleComments(post.id)}
                      className="flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-blue-600 transition"
                    >
                      <MessageCircle className="w-4 h-4" />
                      {post.comments.length} تعليق
                    </button>
                  </div>

                  {/* Comments section */}
                  {expandedComments.has(post.id) && (
                    <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 animate-fade-in-up">
                      {/* Existing comments */}
                      {post.comments.length > 0 && (
                        <div className="space-y-3 mb-4">
                          {post.comments.map((c) => (
                            <div key={c.id} className="flex gap-2">
                              <div className="flex-shrink-0 w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">
                                {c.author.charAt(0)}
                              </div>
                              <div className="flex-1 bg-white rounded-xl px-3 py-2 border border-slate-100">
                                <div className="flex items-center gap-2 mb-0.5">
                                  <span className="text-xs font-bold text-slate-700">{c.author}</span>
                                  <span className="text-xs text-slate-400">{formatDate(c.createdAt)}</span>
                                </div>
                                <p className="text-sm text-slate-600">{c.text}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Comment input */}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={commentInputs[post.id] || ''}
                          onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                          onKeyDown={(e) => { if (e.key === 'Enter') handleComment(post.id); }}
                          placeholder="اكتب تعليقاً..."
                          className="flex-1 px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                        />
                        <button
                          onClick={() => handleComment(post.id)}
                          disabled={!commentInputs[post.id]?.trim()}
                          className="flex items-center justify-center w-9 h-9 rounded-lg bg-cyan-600 text-white hover:bg-cyan-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
                        >
                          <Send className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="mt-8">
        <AdSlot slot="belowContent" />
      </div>
    </div>
  );
}
