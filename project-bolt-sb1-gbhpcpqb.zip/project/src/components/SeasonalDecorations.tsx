import { useMemo } from 'react';
import { Star } from 'lucide-react';
import { useSettings } from '@/context/SettingsContext';
import type { ThemeKey } from '@/types';

export default function SeasonalDecorations() {
  const { settings } = useSettings();
  const theme = settings.seasonalTheme;

  const stars = useMemo(
    () => Array.from({ length: 30 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      top: Math.random() * 100,
      delay: Math.random() * 3,
      duration: 2 + Math.random() * 2,
    })),
    [theme]
  );

  const lanterns = useMemo(
    () => Array.from({ length: 6 }, (_, i) => ({
      id: i,
      left: (i * 18 + 5) % 95,
      delay: i * 0.5,
      size: 40 + Math.random() * 20,
    })),
    [theme]
  );

  const flags = useMemo(
    () => Array.from({ length: 8 }, (_, i) => ({
      id: i,
      left: (i * 13 + 3) % 90,
      delay: i * 0.3,
      duration: 1.5 + Math.random(),
    })),
    [theme]
  );

  if (theme === 'normal') return null;

  // Ramadan theme
  if (theme === 'ramadan') {
    return (
      <div className="fixed inset-0 pointer-events-none z-30 overflow-hidden">
        {/* Twinkling stars */}
        {stars.map((s) => (
          <Star
            key={`star-${s.id}`}
            className="absolute text-yellow-300 animate-twinkle fill-yellow-300"
            style={{
              left: `${s.left}%`,
              top: `${s.top}%`,
              width: '6px',
              height: '6px',
              animationDelay: `${s.delay}s`,
              animationDuration: `${s.duration}s`,
            }}
          />
        ))}

        {/* Lanterns */}
        {lanterns.map((l) => (
          <div
            key={`lantern-${l.id}`}
            className="absolute top-10 animate-float-lantern"
            style={{
              left: `${l.left}%`,
              animationDelay: `${l.delay}s`,
            }}
          >
            <Lantern size={l.size} />
          </div>
        ))}

        {/* Crescent moon top-right */}
        <div className="absolute top-16 left-8 opacity-80">
          <CrescentMoon />
        </div>

        {/* Bottom gradient */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-yellow-900/20 to-transparent" />
      </div>
    );
  }

  // October victory theme
  if (theme === 'october') {
    return (
      <div className="fixed inset-0 pointer-events-none z-30 overflow-hidden">
        {/* Egyptian flags */}
        {flags.map((f) => (
          <div
            key={`flag-${f.id}`}
            className="absolute top-10 animate-float-lantern"
            style={{
              left: `${f.left}%`,
              animationDelay: `${f.delay}s`,
              animationDuration: `${f.duration}s`,
            }}
          >
            <EgyptFlag />
          </div>
        ))}

        {/* Victory banner top */}
        <div className="absolute top-0 left-0 right-0 flex justify-center">
          <div className="bg-gradient-to-r from-red-600 via-white to-black py-1 px-6 rounded-b-xl shadow-lg">
            <span className="text-sm font-bold text-white drop-shadow">
              🇪🇬 ذكرى نصر أكتوبر المجيد 🇪🇬
            </span>
          </div>
        </div>

        {/* Confetti */}
        {Array.from({ length: 20 }, (_, i) => (
          <div
            key={`confetti-${i}`}
            className="absolute w-2 h-2 rounded-full animate-fall-slow"
            style={{
              left: `${(i * 7) % 100}%`,
              backgroundColor: ['#DC2626', '#FFFFFF', '#000000', '#EA580C'][i % 4],
              animationDuration: `${3 + Math.random() * 3}s`,
              animationDelay: `${i * 0.2}s`,
            }}
          />
        ))}
      </div>
    );
  }

  // Eid themes
  if (theme === 'eid_fitr' || theme === 'eid_adha') {
    const colors = theme === 'eid_fitr'
      ? ['#F59E0B', '#FBBF24', '#FCD34D']
      : ['#DC2626', '#EA580C', '#F59E0B'];

    return (
      <div className="fixed inset-0 pointer-events-none z-30 overflow-hidden">
        {/* Floating crescents and stars */}
        {Array.from({ length: 15 }, (_, i) => (
          <div
            key={`eid-${i}`}
            className="absolute animate-float-lantern"
            style={{
              left: `${(i * 13 + 5) % 95}%`,
              top: `${(i * 7 + 10) % 80}%`,
              animationDelay: `${i * 0.3}s`,
              animationDuration: `${2 + (i % 3)}s`,
            }}
          >
            {i % 3 === 0 ? (
              <CrescentMoon small />
            ) : (
              <Star
                className="fill-current"
                style={{ color: colors[i % 3], width: '16px', height: '16px' }}
              />
            )}
          </div>
        ))}

        {/* Top banner */}
        <div className="absolute top-0 left-0 right-0 flex justify-center">
          <div
            className="py-1 px-6 rounded-b-xl shadow-lg"
            style={{ background: `linear-gradient(90deg, ${colors[0]}, ${colors[2]})` }}
          >
            <span className="text-sm font-bold text-white drop-shadow">
              {theme === 'eid_fitr' ? '🌙 عيد فطر مبارك 🌙' : '🌙 عيد أضحى مبارك 🌙'}
            </span>
          </div>
        </div>
      </div>
    );
  }

  return null;
}

function Lantern({ size = 50 }: { size?: number }) {
  return (
    <div style={{ width: size, height: size * 1.2 }}>
      <svg viewBox="0 0 50 60" className="w-full h-full animate-glow-pulse">
        <line x1="25" y1="0" x2="25" y2="8" stroke="#D4AF37" strokeWidth="1.5" />
        <rect x="18" y="6" width="14" height="4" fill="#D4AF37" rx="1" />
        <ellipse cx="25" cy="30" rx="16" ry="20" fill="#FFD700" opacity="0.85" />
        <ellipse cx="25" cy="30" rx="12" ry="16" fill="#FFA500" opacity="0.5" />
        <rect x="20" y="48" width="10" height="3" fill="#D4AF37" rx="1" />
        <line x1="25" y1="51" x2="25" y2="58" stroke="#D4AF37" strokeWidth="1" />
        <circle cx="25" cy="59" r="1.5" fill="#D4AF37" />
      </svg>
    </div>
  );
}

function CrescentMoon({ small = false }: { small?: boolean }) {
  const size = small ? 20 : 48;
  return (
    <svg width={size} height={size} viewBox="0 0 48 48">
      <path
        d="M32 8 C 22 8 14 16 14 26 C 14 36 22 44 32 44 C 24 40 20 33 20 26 C 20 19 24 12 32 8 Z"
        fill="#D4AF37"
        opacity="0.8"
      />
    </svg>
  );
}

function EgyptFlag() {
  return (
    <div className="flex flex-col w-8 h-12 rounded-sm overflow-hidden shadow-md border border-slate-300">
      <div className="flex-1 bg-red-600" />
      <div className="flex-1 bg-white flex items-center justify-center">
        <span className="text-[8px]">🦅</span>
      </div>
      <div className="flex-1 bg-black" />
    </div>
  );
}
