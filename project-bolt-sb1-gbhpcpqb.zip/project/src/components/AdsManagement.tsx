import { ToggleLeft, ToggleRight, Eye, Code, Monitor, Columns, AlignCenter } from 'lucide-react';
import { useSettings } from '@/context/SettingsContext';
import type { AdSlotConfig } from '@/types';

const slotInfo: { key: keyof AdSlotConfig; label: string; icon: typeof Monitor }[] = [
  { key: 'header', label: 'إعلان الهيدر (أعلى الصفحة)', icon: Monitor },
  { key: 'sidebar', label: 'إعلان القائمة الجانبية', icon: Columns },
  { key: 'belowContent', label: 'إعلان أسفل المحتوى', icon: AlignCenter },
];

export default function AdsManagement() {
  const { settings, updateSettings } = useSettings();

  const toggleAds = () => {
    updateSettings({ ...settings, adsEnabled: !settings.adsEnabled });
  };

  const updateSlot = (key: keyof AdSlotConfig, value: string) => {
    updateSettings({
      ...settings,
      adCodes: { ...settings.adCodes, [key]: value },
    });
  };

  return (
    <div className="space-y-6">
      {/* Master toggle */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`p-3 rounded-xl ${settings.adsEnabled ? 'bg-green-50' : 'bg-slate-100'}`}>
            {settings.adsEnabled ? (
              <ToggleRight className="w-8 h-8 text-green-600" />
            ) : (
              <ToggleLeft className="w-8 h-8 text-slate-400" />
            )}
          </div>
          <div>
            <h3 className="font-bold text-slate-800">تشغيل الإعلانات</h3>
            <p className="text-sm text-slate-500">
              {settings.adsEnabled ? 'الإعلانات مفعلة الآن في جميع أنحاء المنصة' : 'الإعلانات متوقفة حالياً'}
            </p>
          </div>
        </div>
        <button
          onClick={toggleAds}
          className={`relative w-16 h-8 rounded-full transition-all ${
            settings.adsEnabled ? 'bg-green-500' : 'bg-slate-300'
          }`}
        >
          <span
            className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow transition-all ${
              settings.adsEnabled ? 'left-1' : 'right-1'
            }`}
          />
        </button>
      </div>

      {/* Ad code inputs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {slotInfo.map(({ key, label, icon: Icon }) => (
          <div key={key} className="bg-white rounded-xl border border-slate-200 p-5 flex flex-col">
            <div className="flex items-center gap-2 mb-3">
              <Icon className="w-5 h-5 text-cyan-600" />
              <h4 className="font-bold text-sm text-slate-700">{label}</h4>
            </div>
            <textarea
              value={settings.adCodes[key]}
              onChange={(e) => updateSlot(key, e.target.value)}
              placeholder="الصق كود الإعلان هنا (HTML / Script)"
              rows={5}
              className="w-full text-xs font-mono p-3 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition resize-none"
              dir="ltr"
            />
            <div className="mt-2 flex items-center gap-1 text-xs text-slate-400">
              <Code className="w-3 h-3" />
              <span>يدعم أكواد Adsterra و Google Ads</span>
            </div>
          </div>
        ))}
      </div>

      {/* Live preview */}
      <div className="bg-slate-900 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Eye className="w-5 h-5 text-cyan-400" />
          <h3 className="font-bold text-white">معاينة مواقع الإعلانات</h3>
          {!settings.adsEnabled && (
            <span className="text-xs text-slate-400 mr-2">(فعّل الإعلانات لرؤية المعاينة)</span>
          )}
        </div>

        {/* Mock page layout */}
        <div className="bg-slate-800 rounded-lg p-4">
          {/* Header ad preview */}
          <PreviewSlot
            code={settings.adCodes.header}
            active={settings.adsEnabled}
            label="الهيدر"
          />

          <div className="flex flex-col sm:flex-row gap-3 mt-3">
            {/* Content area */}
            <div className="flex-1 bg-slate-700 rounded-lg p-4 min-h-[100px] flex items-center justify-center">
              <span className="text-slate-500 text-sm">محتوى الصفحة</span>
            </div>
            {/* Sidebar ad preview */}
            <div className="sm:w-40">
              <PreviewSlot
                code={settings.adCodes.sidebar}
                active={settings.adsEnabled}
                label="القائمة الجانبية"
                vertical
              />
            </div>
          </div>

          {/* Below content ad preview */}
          <PreviewSlot
            code={settings.adCodes.belowContent}
            active={settings.adsEnabled}
            label="أسفل المحتوى"
          />
        </div>
      </div>
    </div>
  );
}

function PreviewSlot({
  code,
  active,
  label,
  vertical = false,
}: {
  code: string;
  active: boolean;
  label: string;
  vertical?: boolean;
}) {
  const hasCode = code.trim().length > 0;

  if (active && hasCode) {
    return (
      <div
        className={`mt-3 ${vertical ? 'min-h-[100px]' : 'min-h-[60px]'} rounded-lg bg-white overflow-auto`}
        dangerouslySetInnerHTML={{ __html: code }}
      />
    );
  }

  return (
    <div
      className={`mt-3 ${vertical ? 'min-h-[100px]' : 'min-h-[60px]'} rounded-lg border-2 border-dashed border-slate-600 flex items-center justify-center`}
    >
      <span className="text-xs text-slate-500">
        {active ? `مساحة إعلان: ${label}` : `${label} (متوقف)`}
      </span>
    </div>
  );
}
