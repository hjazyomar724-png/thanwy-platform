import { useState } from 'react';
import { Plus, Trash2, Library, CheckCircle2, ExternalLink, BookMarked, Pencil, X, Save } from 'lucide-react';
import { useContent } from '@/context/ContentContext';
import { subjects } from '@/data';
import type { LibraryBook } from '@/types';

const typeOptions: LibraryBook['type'][] = ['ملخص', 'كتاب وزارة', 'مفاهيم'];

const emptyForm = {
  title: '',
  subject: subjects[0].name,
  type: 'ملخص' as LibraryBook['type'],
  link: '',
};

export default function LibraryManagement() {
  const { books, addBook, updateBook, deleteBook } = useContent();
  const [form, setForm] = useState({ ...emptyForm });
  const [added, setAdded] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<typeof emptyForm | null>(null);
  const [savedEdit, setSavedEdit] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;

    addBook({
      id: `b-${Date.now()}`,
      title: form.title,
      subject: form.subject,
      type: form.type,
      link: form.link.trim() || '#',
    });

    setForm({ ...emptyForm });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const startEdit = (b: LibraryBook) => {
    setEditingId(b.id);
    setEditForm({
      title: b.title,
      subject: b.subject,
      type: b.type,
      link: b.link === '#' ? '' : b.link,
    });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm(null);
  };

  const saveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm || !editingId || !editForm.title.trim()) return;

    updateBook({
      id: editingId,
      title: editForm.title,
      subject: editForm.subject,
      type: editForm.type,
      link: editForm.link.trim() || '#',
    });

    cancelEdit();
    setSavedEdit(true);
    setTimeout(() => setSavedEdit(false), 2000);
  };

  const typeColors: Record<string, string> = {
    'ملخص': 'bg-amber-100 text-amber-700',
    'كتاب وزارة': 'bg-blue-100 text-blue-700',
    'مفاهيم': 'bg-green-100 text-green-700',
  };

  return (
    <div className="space-y-6">
      {added && (
        <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg px-4 py-3 animate-fade-in-up">
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-medium">تمت إضافة الكتاب بنجاح! يظهر الآن في مركز الملخصات.</span>
        </div>
      )}

      {savedEdit && (
        <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg px-4 py-3 animate-fade-in-up">
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-medium">تم حفظ التعديلات بنجاح! تم تحديث الكتاب في مركز الملخصات.</span>
        </div>
      )}

      {/* Add form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Plus className="w-5 h-5 text-cyan-600" />
          <h3 className="font-bold text-slate-800">إضافة كتاب / ملخص جديد</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">اسم الكتاب / الملخص</label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="مثال: ملخص النحو الوافي 2026"
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">المادة</label>
            <select
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.name}>{s.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">النوع</label>
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value as LibraryBook['type'] })}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
            >
              {typeOptions.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">رابط التحميل / القراءة</label>
            <input
              type="text"
              value={form.link}
              onChange={(e) => setForm({ ...form, link: e.target.value })}
              placeholder="https://..."
              dir="ltr"
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
            />
          </div>
        </div>

        <button
          type="submit"
          className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold px-6 py-3 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg"
        >
          <Plus className="w-5 h-5" />
          إضافة الكتاب
        </button>
      </form>

      {/* Existing books */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Library className="w-5 h-5 text-slate-600" />
          <h3 className="font-bold text-slate-800">الكتب والملخصات المضافة ({books.length})</h3>
        </div>
        {books.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-6">لا توجد كتب بعد</p>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {books.map((book) => (
              <div key={book.id} className="rounded-lg bg-slate-50 border border-slate-100 overflow-hidden">
                {/* Book row */}
                <div className="flex items-center gap-3 p-3">
                  <BookMarked className="w-5 h-5 text-cyan-600 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-700 font-medium truncate">{book.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-slate-400">{book.subject}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${typeColors[book.type]}`}>{book.type}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {book.link !== '#' && (
                      <a
                        href={book.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-shrink-0 p-1.5 rounded-lg text-cyan-500 hover:bg-cyan-50 transition"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                    <button
                      onClick={() => startEdit(book)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-cyan-600 hover:bg-cyan-50 transition text-xs font-medium"
                    >
                      <Pencil className="w-4 h-4" />
                      تعديل
                    </button>
                    <button
                      onClick={() => deleteBook(book.id)}
                      className="flex-shrink-0 p-1.5 rounded-lg text-red-400 hover:bg-red-50 hover:text-red-600 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Inline edit form */}
                {editingId === book.id && editForm && (
                  <form
                    onSubmit={saveEdit}
                    className="border-t border-slate-200 bg-white p-4 space-y-3 animate-fade-in-up"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-bold text-slate-700">تعديل الكتاب</span>
                      <button
                        type="button"
                        onClick={cancelEdit}
                        className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 transition"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">اسم الكتاب</label>
                      <input
                        type="text"
                        value={editForm.title}
                        onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">المادة</label>
                        <select
                          value={editForm.subject}
                          onChange={(e) => setEditForm({ ...editForm, subject: e.target.value })}
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                        >
                          {subjects.map((s) => (
                            <option key={s.id} value={s.name}>{s.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">النوع</label>
                        <select
                          value={editForm.type}
                          onChange={(e) => setEditForm({ ...editForm, type: e.target.value as LibraryBook['type'] })}
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                        >
                          {typeOptions.map((t) => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">رابط التحميل / القراءة</label>
                      <input
                        type="text"
                        value={editForm.link}
                        onChange={(e) => setEditForm({ ...editForm, link: e.target.value })}
                        placeholder="https://..."
                        dir="ltr"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                      />
                    </div>

                    <button
                      type="submit"
                      className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold px-5 py-2.5 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg text-sm"
                    >
                      <Save className="w-4 h-4" />
                      حفظ التعديلات
                    </button>
                  </form>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
