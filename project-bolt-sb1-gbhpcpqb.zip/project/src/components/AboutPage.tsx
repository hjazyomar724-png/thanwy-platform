import { GraduationCap, Target, Users, Phone, Mail, Headphones } from 'lucide-react';
import AdSlot from '@/components/AdSlot';

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
      <div className="text-center mb-12">
        <div className="inline-flex bg-gradient-to-br from-cyan-500 to-blue-600 p-4 rounded-2xl mb-6">
          <GraduationCap className="w-12 h-12 text-white" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-4">من نحن</h1>
        <p className="text-slate-600 text-lg leading-relaxed max-w-2xl mx-auto">
          منصة الطالب المصري هي منصة تعليمية مجانية تهدف إلى مساعدة طلاب الثانوية العامة في مصر
          على تحقيق أعلى الدرجات من خلال توفير محتوى تعليمي عالي الجودة ومنظم.
        </p>
      </div>

      <AdSlot slot="header" />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <Target className="w-8 h-8 text-cyan-600 mb-3" />
          <h3 className="font-bold text-slate-800 mb-2">رسالتنا</h3>
          <p className="text-sm text-slate-500 leading-relaxed">
            توفير تعليم عادل ومتاح للجميع، ومساعدة كل طالب في الوصول إلى إمكاناته الكاملة.
          </p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <Users className="w-8 h-8 text-blue-600 mb-3" />
          <h3 className="font-bold text-slate-800 mb-2">رؤيتنا</h3>
          <p className="text-sm text-slate-500 leading-relaxed">
            أن نكون المنصة التعليمية الأولى لطلاب الثانوية العامة في مصر والوطن العربي.
          </p>
        </div>
      </div>

      {/* Support & Contact */}
      <div className="mt-8 bg-gradient-to-br from-cyan-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-white/20 p-3 rounded-xl">
            <Headphones className="w-7 h-7" />
          </div>
          <div>
            <h3 className="font-bold text-xl">الدعم الفني والتواصل</h3>
            <p className="text-sm text-blue-100">لأي استفسار أو مشكلة في الحسابات، تواصل معنا مباشرة</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <a
            href="tel:01099741582"
            className="flex items-center gap-3 bg-white/10 backdrop-blur rounded-xl p-4 hover:bg-white/20 transition border border-white/20"
          >
            <div className="bg-white/20 p-2.5 rounded-lg">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-blue-200">رقم الدعم الفني</div>
              <div className="font-bold text-lg" dir="ltr">01099741582</div>
            </div>
          </a>
          <a
            href="mailto:hjazyomar724@gmail.com"
            className="flex items-center gap-3 bg-white/10 backdrop-blur rounded-xl p-4 hover:bg-white/20 transition border border-white/20"
          >
            <div className="bg-white/20 p-2.5 rounded-lg">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-blue-200">البريد الإلكتروني</div>
              <div className="font-bold text-sm" dir="ltr">hjazyomar724@gmail.com</div>
            </div>
          </a>
        </div>
      </div>

      <div className="mt-8">
        <AdSlot slot="belowContent" />
      </div>
    </div>
  );
}
