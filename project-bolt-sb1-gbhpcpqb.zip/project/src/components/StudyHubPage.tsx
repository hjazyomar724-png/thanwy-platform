import { useState } from 'react';
import { Library, Download, BookOpen, Search, FileText, Flag } from 'lucide-react';
import { useContent } from '@/context/ContentContext';
import AdSlot from '@/components/AdSlot';
import ReportModal from '@/components/ReportModal';
import type { LibraryBook } from '@/types';

const typeColors: Record<string, string> = {
  'ملخص': 'bg-amber-100 text-amber-700 border-amber-200',
  'كتاب وزارة': 'bg-blue-100 text-blue-700 border-blue-200',
  'مفاهيم': 'bg-green-100 text-green-700 border-green-200',
};

const typeIcons: Record<string, typeof FileText> = {
  'ملخص': FileText,
  'كتاب وزارة': BookOpen,
  'مفاهيم': Library,
};

export default function StudyHubPage() {
  const { books } = useContent();
  const [search, setSearch] = useState('');
  const [filterSubject, setFilterSubject] = useState('الكل');
  const [filterType, setFilterType] = useState('الكل');
  const [reportOpen, setReportOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState({ targetType: 'كتاب' as const, targetTitle: '' });

  const subjectsList = Array.from(new Set(books.map((b) => b.subject)));
  const typesList = Array.from(new Set(books.map((b) => b.type)));

  const filtered = books.filter((b) => {
    const matchSearch = b.title.includes(search) || b.subject.includes(search);
    const matchSubject = filterSubject === 'الكل' || b.subject === filterSubject;
    const matchType = filterType === 'الكل' || b.type === filterType;
    return matchSearch && matchSubject && matchType;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
      <div className="text-center mb-10">
        <div className="inline-flex bg-gradient-to-br from-cyan-500 to-blue-600 p-3 rounded-2xl mb-4">
          <Library className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-3">مركز الملخصات والكتب الدراسية</h1>
        <p className="text-slate-500">تصفح كتب الوزارة ومجلدات المفاهيم والملخصات</p>
      </div>

      <AdSlot slot="header" />

      {/* Search & filters */}
      <div className="mt-8 bg-white rounded-xl border border-slate-200 p-4 space-y-4">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن كتاب أو ملخص..."
            className="w-full pr-11 pl-4 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterChip label="الكل" active={filterSubject === 'الكل'} onClick={() => setFilterSubject('الكل')} />
          {subjectsList.map((s) => (
            <FilterChip key={s} label={s} active={filterSubject === s} onClick={() => setFilterSubject(s)} />
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterChip label="كل الأنواع" active={filterType === 'الكل'} onClick={() => setFilterType('الكل')} />
          {typesList.map((t) => (
            <FilterChip key={t} label={t} active={filterType === t} onClick={() => setFilterType(t)} />
          ))}
        </div>
      </div>

      {/* Books grid */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Search className="w-12 h-12 text-slate-300 mb-4" />
          <p className="text-slate-400">لا توجد نتائج مطابقة</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {filtered.map((book) => {
            const Icon = typeIcons[book.type] || FileText;
            return (
              <div
                key={book.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1 group"
              >
                <div className="h-1.5 bg-gradient-to-r from-cyan-500 to-blue-600" />
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="bg-cyan-50 p-3 rounded-xl group-hover:scale-110 transition">
                      <Icon className="w-7 h-7 text-cyan-600" />
                    </div>
                    <span className={`text-xs px-3 py-1 rounded-full font-medium border ${typeColors[book.type]}`}>
                      {book.type}
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-800 mb-1 leading-snug">{book.title}</h3>
                  <p className="text-xs text-slate-400 mb-4">{book.subject}</p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => book.link !== '#' && window.open(book.link, '_blank')}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-gradient-to-r from-cyan-600 to-blue-700 text-white text-sm font-bold py-2.5 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition group-hover:shadow-lg"
                    >
                      <BookOpen className="w-4 h-4" />
                      تصفح
                    </button>
                    <button
                      onClick={() => book.link !== '#' && window.open(book.link, '_blank')}
                      className="flex items-center justify-center gap-1.5 bg-slate-100 text-slate-600 text-sm font-bold py-2.5 px-4 rounded-xl hover:bg-slate-200 transition"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        setReportTarget({ targetType: 'كتاب', targetTitle: book.title });
                        setReportOpen(true);
                      }}
                      className="flex items-center justify-center gap-1.5 bg-amber-50 text-amber-600 text-sm font-bold py-2.5 px-4 rounded-xl hover:bg-amber-100 transition"
                      title="إبلاغ عن خطأ"
                    >
                      <Flag className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-8">
        <AdSlot slot="belowContent" />
      </div>

      <ReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        targetType={reportTarget.targetType}
        targetTitle={reportTarget.targetTitle}
      />
    </div>
  );
}

function FilterChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-1.5 rounded-lg text-sm font-medium transition ${
        active
          ? 'bg-cyan-600 text-white'
          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
      }`}
    >
      {label}
    </button>
  );
}
