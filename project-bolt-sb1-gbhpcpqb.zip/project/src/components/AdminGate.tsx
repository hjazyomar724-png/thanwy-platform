import { useState } from 'react';
import { Lock, ShieldCheck, ArrowRight, AlertCircle } from 'lucide-react';

const ADMIN_PASSWORD = '292009zZ@#';

interface AdminGateProps {
  onSuccess: () => void;
}

export default function AdminGate({ onSuccess }: AdminGateProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      onSuccess();
    } else {
      setError(true);
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div
          className={`bg-white rounded-2xl shadow-xl border border-slate-200 p-8 ${
            shake ? 'animate-[shake_0.5s]' : ''
          }`}
          style={shake ? { animation: 'shake 0.5s' } : undefined}
        >
          {/* Icon */}
          <div className="flex flex-col items-center mb-6">
            <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-4 rounded-2xl mb-4">
              <ShieldCheck className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-slate-800">لوحة تحكم الإدارة</h2>
            <p className="text-sm text-slate-500 mt-1">أدخل كلمة المرور للدخول إلى لوحة التحكم</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                كلمة المرور
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError(false);
                  }}
                  className="w-full pr-11 pl-4 py-3 rounded-xl border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
                  placeholder="••••••••"
                  autoFocus
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-red-600 bg-red-50 rounded-lg px-4 py-3 animate-fade-in-up">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm font-medium">كلمة المرور غير صحيحة. حاول مرة أخرى.</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold py-3 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition-all shadow-lg hover:shadow-xl"
            >
              دخول
              <ArrowRight className="w-5 h-5 rotate-180" />
            </button>
          </form>
        </div>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-8px); }
          75% { transform: translateX(8px); }
        }
      `}</style>
    </div>
  );
}
