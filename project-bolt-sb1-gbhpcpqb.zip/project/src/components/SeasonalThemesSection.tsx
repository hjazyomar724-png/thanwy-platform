import { Moon, Flag, Sparkles, PartyPopper, Check } from 'lucide-react';
import { useSettings } from '@/context/SettingsContext';
import type { ThemeKey } from '@/types';

const themeOptions: {
  key: ThemeKey;
  label: string;
  description: string;
  icon: typeof Moon;
  preview: string;
}[] = [
  {
    key: 'normal',
    label: 'الوضع الطبيعي',
    description: 'المظهر المعتاد للمنصة',
    icon: Sparkles,
    preview: 'from-slate-50 to-slate-100',
  },
  {
    key: 'ramadan',
    label: 'زينة شهر رمضان',
    description: 'فوانيس، هلال، نجوم متلألئة، تأثيرات رمضانية هادئة',
    icon: Moon,
    preview: 'from-indigo-950 to-blue-950',
  },
  {
    key: 'october',
    label: 'احتفال نصر أكتوبر',
    description: 'أعلام مصر، تأثيرات وطنية احتفالية بالانتصار',
    icon: Flag,
    preview: 'from-red-600 via-white to-black',
  },
  {
    key: 'eid_fitr',
    label: 'عيد الفطر',
    description: 'زينة احتفالية بألوان ذهبية وهلال وأربعاء',
    icon: PartyPopper,
    preview: 'from-amber-300 to-yellow-200',
  },
  {
    key: 'eid_adha',
    label: 'عيد الأضحى',
    description: 'زينة احتفالية بألوان حمراء وبرتقالية',
    icon: PartyPopper,
    preview: 'from-red-500 to-orange-400',
  },
];

export default function SeasonalThemesSection() {
  const { settings, updateSettings } = useSettings();

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-700">
          اختر طابع وزينة المنصة حسب المناسبة. يتم تطبيق التغيير فوراً على كامل الموقع.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {themeOptions.map(({ key, label, description, icon: Icon, preview }) => {
          const active = settings.seasonalTheme === key;
          return (
            <button
              key={key}
              onClick={() => updateSettings({ ...settings, seasonalTheme: key })}
              className={`relative bg-white rounded-xl border-2 p-4 text-right transition-all hover:shadow-lg ${
                active ? 'border-cyan-500 ring-2 ring-cyan-200' : 'border-slate-200'
              }`}
            >
              {/* Preview swatch */}
              <div
                className={`h-16 rounded-lg bg-gradient-to-br ${preview} mb-3 flex items-center justify-center relative overflow-hidden`}
              >
                <Icon className="w-7 h-7 text-white drop-shadow-lg" />
                {active && (
                  <div className="absolute top-1 right-1 bg-cyan-500 rounded-full p-1">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>

              <h4 className="font-bold text-sm text-slate-800">{label}</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">{description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
