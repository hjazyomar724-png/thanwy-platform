import { useState, useRef, useEffect, useCallback } from 'react';
import { Sparkles, Send, Bot, User, Code2, RotateCcw, AlertCircle } from 'lucide-react';
import AdSlot from '@/components/AdSlot';

interface Message {
  id: string;
  role: 'user' | 'ai';
  text: string;
}

const welcomeMessage: Message = {
  id: 'm-welcome',
  role: 'ai',
  text: 'أهلاً بك! أنا المُسْتَشَارُ الدَّوَادِيُّ الذَّكِيُّ، مساعدك الذكي في رحلة الثانوية العامة. اسألني عن أي درس أو مفهوم أو سؤال يصعب عليك فهمه، وسأشرحه لك ببساطة.\n\nيمكنني تذكر محادثتنا السابقة، فلا تتردد في متابعة أي نقطة أو طلب توضيح إضافي.',
};

// Smart fallback used when the Gemini API key is not yet configured
function generateFallbackResponse(
  userText: string,
  history: Message[]
): string {
  const text = userText.trim();

  const userMessages = history.filter((m) => m.role === 'user');
  const aiMessages = history.filter((m) => m.role === 'ai');
  const lastUserMsg = userMessages[userMessages.length - 1]?.text || '';
  const lastAiMsg = aiMessages[aiMessages.length - 1]?.text || '';

  const isClarification =
    /مش فاهم|مش فاهمة|وضح|وضحلي|اشرح اكتر|اكتر شرح|مو فاهم|مافهمتش|مافهمت|أكتر|توضيح|ممكن توضح|بس مش|لاكن مش|بس انا/i.test(text);

  const isFollowingUp =
    /طب|بعد كده|وبعدين|وكي|طيب|وممكن|وهل|وكمان|ثم|وبعد/i.test(text);

  const isGreeting = /السلام|مرحبا|اهلا|هاي|hello|hi|صباح|مساء/i.test(text);
  const isThanks = /شكرا|متشكر|thanks|thank/i.test(text);
  const isAboutPhysics = /نيوتن|حركة|سرعة|قوة|طاقة|كهرب|مغناط|فيزياء|ميكانيكا|حرارة|ضوء|موائع/i.test(text);
  const isAboutChemistry = /ذرة|عنصر|مركب|تفاعل|كيمياء|أيون|رابطة|مول|حجم|تركيز|أحماض|قواعد/i.test(text);
  const isAboutArabic = /نحو|بلاغة|تشبيه|استعارة|إعراب|كناية|محسن|طباق|جناس|صرف|لغة عربية/i.test(text);
  const isAboutMath = /معادلة|جبر|هندسة|تفاضل|تكامل|إحصاء|احتمال|متجه|مثلث|دائرة|رياضيات|نسبة/i.test(text);

  if (isClarification && lastAiMsg) {
    const topicHint = lastUserMsg.slice(0, 30);
    return `بالتأكيد! دعني أوضح لك أكثر بما يتعلق بسؤالك السابق عن "${topicHint}...":\n\nفي الشرح السابق ذكرنا الخطوات الأساسية. دعني أبسطها لك أكثر:\n\n1. الفكرة الرئيسية هي أن المفهوم يُبنى خطوة بخطوة، فلا تنتقل للخطوة التالية قبل فهم الحالية تماماً.\n2. تخيل الموضوع كمثال من الحياة اليومية — هذا يساعد على التذكر والفهم العميق.\n3. إذا كان هناك قانون أو قاعدة، اكتبه على ورقة وعلّقه أمامك أثناء الحل.\n\nهل أصبح الأمر أوضح الآن؟ أم تريدني أن أضرب لك مثالاً رقمياً محدداً؟`;
  }

  if (isFollowingUp && lastAiMsg) {
    return `ممتاز أنك تتابع النقطة! بالتواصل مع ما شرحته لك في الرسالة السابقة:\n\nالخطوة التالية بعد ما ذكرناه هي التطبيق العملي. إليك كيف:\n\n• ابدأ بمثال بسيط جداً للتحقق من فهمك\n• ثم انتقل لمثال متوسط الصعوبة\n• وأخيراً تحدّى نفسك بمثال من امتحانات السنوات السابقة\n\nتذكر: كل سؤال تحله يضيف لك مهارة جديدة. وإذا واجهتك أي صعوبة في التطبيق، أنا هنا لمساعدتك خطوة بخطوة!`;
  }

  if (isGreeting) {
    return `أهلاً ومرحباً بك! يسعدني مساعدتك اليوم.\n\nيمكنك سؤالي عن:\n• أي درس في الفيزياء أو الكيمياء أو الأحياء\n• قواعد النحو أو البلاغة في اللغة العربية\n• حل المسائل في الرياضيات\n• أي مفهوم تجد صعوبة في فهمه\n\nما المادة أو الدرس الذي تريد أن نبدأ به؟`;
  }

  if (isThanks) {
    return `العفو! سعيد جداً أنني استطعت مساعدتك.\n\nلا تتردد في العودة بأي سؤال آخر في أي وقت — أنا هنا دائماً لمساعدتك على التفوق.\n\nاستمر في المذاكرة بتركيز، وستحقق نتائج رائعة بإذن الله!`;
  }

  if (isAboutPhysics) {
    if (/نيوتن/i.test(text)) {
      return `سؤال رائع عن قوانين نيوتن!\n\nقانون نيوتن الثاني ينص على أن: ق = ك × ت (القوة = الكتلة × التسارع)\n\nبمعنى أن القوة المؤثرة على جسم تساوي حاصل ضرب كتلته في تسارعه.\n\nمثال: جسم كتلته 2 كجم وتسارعه 5 م/ث²، فالقوة = 2 × 5 = 10 نيوتن.\n\nهل تريد أن نطبق على مثال أصعب، أو تشرح لك قانون نيوتن الأول أو الثالث أيضاً؟`;
    }
    if (/طاقة|حركة|سرعة/i.test(text)) {
      return `دعنا نتحدث عن الطاقة والحركة:\n\nطاقة الحركة (E) = ½ × ك × ع² (نصف الكتلة في مربع السرعة)\n\nمثال: جسم كتلته 2 كجم يتحرك بسرعة 10 م/ث:\nE = ½ × 2 × (10)² = ½ × 2 × 100 = 100 جول\n\nهل تريد تطبيقاً آخر، أو تشرح لك طاقة الوضع أيضاً؟`;
    }
    return `سؤال ممتاز في الفيزياء!\n\nالفيزياء مادة تعتمد على الفهم وليس الحفظ. إليك منهجية الحل:\n\n1. اقرأ السؤال بتركيز وحدد المعطيات والمطلوب\n2. ارسم مخططاً بسيطاً إذا كان السؤال يتضمن حركة أو قوى\n3. اكتب القانون المناسب قبل التعويض\n4. عوّض القيم بوحداتها الصحيحة\n5. تحقق من أن وحدة الإجابة منطقية\n\nهل تريد أن نتعمق في موضوع محدد من الفيزياء؟`;
  }

  if (isAboutChemistry) {
    return `سؤال مهم في الكيمياء!\n\nالكيمياء مادة تراكمية — كل فصل يبني على السابق. نصائح للفهم:\n\n1. احفظ رموز العناصر وأرقامها الذرية أولاً\n2. افهم أنواع الروابط الكيميائية (أيونية، تساهمية، فلزية)\n3. تدرب على الموازنة الكيميائية بكثرة\n4. ارتب المعادلات في ورقة ملخص للمراجعة\n\nإذا كان عندك سؤال محدد عن تفاعل أو عنصر معين، اكتبه لي وسأشرحه بالتفصيل!`;
  }

  if (isAboutArabic) {
    if (/تشبيه|استعارة/i.test(text)) {
      return `سؤال جميل في البلاغة!\n\nالفرق بين التشبيه والاستعارة:\n\n• التشبيه: تشبيه شيء بشيء آخر لبيان وجه شبه بينهما، وأركانه: (المشبه، المشبه به، أداة التشبيه، وجه الشبه). مثال: "العلم كالنور" — هنا شبهنا العلم بالنور.\n\n• الاستعارة: تشبيه حُذف أحد طرفيه (المشبه أو المشبه به). مثال: "رأيت أسداً يخطب" — استعارة تصريحية حيث شبهنا الرجل بالأسد وحُذف المشبه وصرّح بالمشبه به.\n\nهل تريد أمثلة إضافية أو التوضيح أكثر؟`;
    }
    return `سؤال ممتاز في اللغة العربية!\n\nاللغة العربية في الثانوية العامة تنقسم إلى:\n• النحو: دراسة الإعراب والقواعد\n• البلاغة: التشبيه، الاستعارة، الكناية، المحسنات البديعية\n• الأدب والنصوص: دراسة العصور الأدبية وتحليل القصائد\n\nنصيحتي: احفظ القاعدة ثم طبقها على أمثلة كثيرة. هل تريد أن نبدأ بدرس محدد؟`;
  }

  if (isAboutMath) {
    return `سؤال ممتاز في الرياضيات!\n\nالرياضيات تحتاج إلى ممارسة يومية. منهجية حل أي مسألة:\n\n1. اقرأ المسألة مرتين على الأقل\n2. حدد المعطيات والمطلوب بوضوح\n3. اكتب القانون أو القاعدة المستخدمة\n4. حُل خطوة بخطوة دون تخطي\n5. تحقق من الإجابة بالتعويض العكسي\n\nإذا كانت معادلة من الدرجة الثانية، نستخدم القانون العام:\nس = (-ب ± جذر(ب² - 4أج)) / 2أ\n\nاكتب لي المسألة التي تريد حلها وسأشرحها لك خطوة بخطوة!`;
  }

  const turnCount = userMessages.length;
  if (turnCount === 0) {
    return `سؤال ممتاز للبدء!\n\nدعني أساعدك في فهم هذا الموضوع. أولاً، من المهم أن تعرف أن كل موضوع في الثانوية العامة يمكن تقسيمه إلى أجزاء صغيرة يسهل فهمها.\n\n1. ابدأ بقراءة الدرس قراءة سريعة للحصول على فكرة عامة\n2. ثم اقرأه بتركيز مع تدوين النقاط المهمة\n3. حُل الأسئلة المباشرة بعد كل درس\n4. راجع ما تعلمته بعد يومين لتثبيته\n\nهل يمكنك تحديد الجزء الذي تجد فيه صعوبة لنتناوله بالتفصيل؟`;
  }

  return `شكراً لسؤالك! دعني أساعدك.\n\nبناءً على ما ناقشناه سابقاً، أرى أنك مهتم بالفهم العميق وهذا نهج ممتاز.\n\nللإجابة على سؤالك الحالي:\n• الموضوع يتطلب تطبيق ما تعلمناه في الخطوات السابقة\n• اربط بين المفاهيم التي درسناها معاً\n• حاول التطبيق على مثال قبل أن أساعدك بالتفصيل\n\nاكتب لي تفاصيل أكثر عن الموضوع أو السؤال المحدد، وسأقدم لك شرحاً مفصلاً خطوة بخطوة!`;
}

export default function AIChatPage() {
  const [messages, setMessages] = useState<Message[]>([welcomeMessage]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [apiError, setApiError] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, scrollToBottom]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userText = input.trim();
    const userMsg: Message = { id: `m-${Date.now()}`, role: 'user', text: userText };

    // Store full conversation history including the new user message
    const updatedHistory = [...messages, userMsg];

    setMessages(updatedHistory);
    setInput('');
    setIsTyping(true);

    // Build the conversation payload for the API (map 'ai' -> 'model' for Gemini)
    const apiMessages = updatedHistory
      .filter((m) => m.id !== 'm-welcome')
      .map((m) => ({
        role: m.role === 'user' ? 'user' : 'model',
        text: m.text,
      }));

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/ai-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({ messages: apiMessages }),
      });

      if (!response.ok) {
        throw new Error(`Request failed (${response.status})`);
      }

      const data = await response.json();

      if (data.reply && data.reply.length > 0) {
        // Real Gemini API response
        const aiMsg: Message = {
          id: `m-${Date.now()}-ai`,
          role: 'ai',
          text: data.reply,
        };
        setMessages((prev) => [...prev, aiMsg]);
        setApiError(false);
      } else {
        // API key not configured or API error — use smart fallback
        const fallbackText = generateFallbackResponse(userText, updatedHistory);
        const aiMsg: Message = {
          id: `m-${Date.now()}-ai`,
          role: 'ai',
          text: fallbackText,
        };
        setMessages((prev) => [...prev, aiMsg]);
        setApiError(true);
      }
    } catch {
      // Network or other error — use smart fallback
      const fallbackText = generateFallbackResponse(userText, updatedHistory);
      const aiMsg: Message = {
        id: `m-${Date.now()}-ai`,
        role: 'ai',
        text: fallbackText,
      };
      setMessages((prev) => [...prev, aiMsg]);
      setApiError(true);
    }

    setIsTyping(false);
  };

  const handleReset = () => {
    setMessages([welcomeMessage]);
    setInput('');
    setIsTyping(false);
    setApiError(false);
  };

  const renderText = (text: string) => {
    return text.split('\n').map((line, i) => (
      <span key={i}>
        {line}
        {i < text.split('\n').length - 1 && <br />}
      </span>
    ));
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in-up">
      {/* Header */}
      <div className="bg-gradient-to-br from-indigo-600 via-purple-700 to-blue-800 rounded-2xl p-6 mb-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 30% 50%, white 1px, transparent 1px)',
          backgroundSize: '30px 30px',
        }} />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-white/20 backdrop-blur p-4 rounded-2xl border border-white/30">
              <Sparkles className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-extrabold text-white">
                المُسْتَشَارُ الدَّوَادِيُّ الذَّكِيُّ
              </h1>
              <p className="text-sm text-blue-100">مساعدك الذكي لثانوية عامة</p>
            </div>
          </div>
          {/* Reset button */}
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 bg-white/10 backdrop-blur border border-white/20 text-white text-xs font-medium px-3 py-2 rounded-lg hover:bg-white/20 transition"
            title="بدء محادثة جديدة"
          >
            <RotateCcw className="w-4 h-4" />
            محادثة جديدة
          </button>
        </div>
        <div className="relative mt-4 pt-4 border-t border-white/20 flex items-center justify-center gap-2 text-xs text-blue-100">
          <span>مدعوم بتقنيات جيميناي العالمية</span>
          <span className="text-white/40">|</span>
          <span className="flex items-center gap-1">
            <Code2 className="w-3.5 h-3.5" />
            مطور بواسطة المهندس عمر حجازي (Omar Hegazy)
          </span>
        </div>
      </div>

      <AdSlot slot="header" />

      {/* API status notice */}
      {apiError && (
        <div className="mt-4 flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3 animate-fade-in-up">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span className="text-xs">يعمل المستشار حالياً في الوضع المحلي. لتفعيل الردود الذكية الكاملة، يتم تجهيز مفتاح Gemini API.</span>
        </div>
      )}

      {/* Chat container */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden mt-6">
        {/* Messages */}
        <div ref={scrollRef} className="h-[460px] overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 animate-fade-in-up ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center ${
                msg.role === 'ai'
                  ? 'bg-gradient-to-br from-indigo-500 to-purple-600'
                  : 'bg-gradient-to-br from-cyan-500 to-blue-600'
              }`}>
                {msg.role === 'ai' ? <Bot className="w-5 h-5 text-white" /> : <User className="w-5 h-5 text-white" />}
              </div>
              <div className={`max-w-[75%] rounded-2xl px-4 py-3 ${
                msg.role === 'ai'
                  ? 'bg-white border border-slate-200 text-slate-700'
                  : 'bg-gradient-to-br from-cyan-600 to-blue-700 text-white'
              }`}>
                <p className="text-sm leading-relaxed whitespace-pre-line">{renderText(msg.text)}</p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3 animate-fade-in-up">
              <div className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <span className="text-xs text-slate-400 font-medium">المستشار يكتب الآن...</span>
                </div>
              </div>
            </div>
          )}

          {/* Auto-scroll anchor */}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <form onSubmit={handleSend} className="border-t border-slate-200 p-4 flex items-center gap-3 bg-white">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="اكتب سؤالك هنا... (المستشار يتذكر محادثتك السابقة)"
            className="flex-1 px-4 py-3 rounded-xl border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition text-slate-800"
          />
          <button
            type="submit"
            disabled={!input.trim() || isTyping}
            className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-700 text-white hover:from-indigo-700 hover:to-purple-800 transition shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>

      {/* Conversation info */}
      <div className="mt-3 flex items-center justify-center gap-2 text-xs text-slate-400">
        <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
        <span>المستشار يتذكر {messages.filter((m) => m.role === 'user').length} سؤال سابق في هذه المحادثة</span>
      </div>

      {/* Suggested questions */}
      <div className="mt-4 flex flex-wrap gap-2">
        {['اشرح لي قانون نيوتن الثاني', 'ما هو الفرق بين التشبيه والاستعارة؟', 'كيف أحل معادلات الدرجة الثانية؟', 'مش فاهم، وضح أكتر'].map((q) => (
          <button
            key={q}
            onClick={() => setInput(q)}
            disabled={isTyping}
            className="text-xs bg-white border border-slate-200 text-slate-600 px-3 py-2 rounded-lg hover:border-indigo-300 hover:text-indigo-600 transition disabled:opacity-50"
          >
            {q}
          </button>
        ))}
      </div>
    </div>
  );
}
