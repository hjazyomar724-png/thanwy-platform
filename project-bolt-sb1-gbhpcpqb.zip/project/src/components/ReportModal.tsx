import { useState } from 'react';
import { X, Send, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useContent } from '@/context/ContentContext';
import type { ErrorReport } from '@/types';

interface ReportModalProps {
  open: boolean;
  onClose: () => void;
  targetType: ErrorReport['targetType'];
  targetTitle: string;
}

export default function ReportModal({ open, onClose, targetType, targetTitle }: ReportModalProps) {
  const { addReport } = useContent();
  const [message, setMessage] = useState('');
  const [studentName, setStudentName] = useState('');
  const [sent, setSent] = useState(false);

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    addReport({
      id: `r-${Date.now()}`,
      targetType,
      targetTitle,
      message: message.trim(),
      studentName: studentName.trim() || 'طالب غير مسجل',
      status: 'جديد',
      createdAt: Date.now(),
    });

    setSent(true);
    setMessage('');
    setStudentName('');
    setTimeout(() => {
      setSent(false);
      onClose();
    }, 1800);
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in-up"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="bg-amber-50 p-2 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
            <h3 className="font-bold text-slate-800">الإبلاغ عن خطأ</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {sent ? (
          <div className="p-8 text-center animate-fade-in-up">
            <CheckCircle2 className="w-14 h-14 text-green-500 mx-auto mb-4" />
            <p className="font-bold text-slate-800 mb-1">تم إرسال البلاغ بنجاح</p>
            <p className="text-sm text-slate-500">سيقوم فريق الإدارة بمراجعة البلاغ في أقرب وقت</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {/* Target info */}
            <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
              <span className="text-xs text-slate-400">البلاغ عن: </span>
              <span className="text-sm font-medium text-slate-700">{targetType}</span>
              <p className="text-sm text-slate-600 mt-1 truncate">{targetTitle}</p>
            </div>

            {/* Student name */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">الاسم (اختياري)</label>
              <input
                type="text"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder="اكتب اسمك..."
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
              />
            </div>

            {/* Message */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">وصف الخطأ / الملاحظة</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
                placeholder="اشرح الخطأ أو الملاحظة التي وجدتها..."
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800 resize-none"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={!message.trim()}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold py-3 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
              إرسال البلاغ
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
