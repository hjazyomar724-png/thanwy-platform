import { useState } from 'react';
import { useContent } from '@/context/ContentContext';
import {
  ClipboardCheck, Clock, Play, CheckCircle2, XCircle,
  RotateCcw, Trophy, ChevronLeft, AlertCircle, Flag,
} from 'lucide-react';
import AdSlot from '@/components/AdSlot';
import ReportModal from '@/components/ReportModal';
import type { QuizQuestion } from '@/types';

const difficultyColors: Record<string, string> = {
  'سهل': 'bg-green-100 text-green-700',
  'متوسط': 'bg-yellow-100 text-yellow-700',
  'صعب': 'bg-red-100 text-red-700',
};

const labels = ['A', 'B', 'C', 'D'];

export default function ExamsPage() {
  const { questions } = useContent();
  const [activeQuiz, setActiveQuiz] = useState<QuizQuestion[] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState({ targetType: 'سؤال' as const, targetTitle: '' });

  const subjectsWithQuestions = Array.from(new Set(questions.map((q) => q.subject)));

  const startQuiz = (subject: string) => {
    const filtered = questions.filter((q) => q.subject === subject);
    if (filtered.length === 0) return;
    setActiveQuiz(filtered);
    setCurrentIndex(0);
    setSelected(null);
    setAnswers([]);
    setShowResult(false);
  };

  const startAllQuiz = () => {
    if (questions.length === 0) return;
    setActiveQuiz(questions);
    setCurrentIndex(0);
    setSelected(null);
    setAnswers([]);
    setShowResult(false);
  };

  const handleSelect = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
  };

  const handleNext = () => {
    if (selected === null || !activeQuiz) return;
    const newAnswers = [...answers, selected];
    setAnswers(newAnswers);

    if (currentIndex + 1 < activeQuiz.length) {
      setCurrentIndex(currentIndex + 1);
      setSelected(null);
    } else {
      setShowResult(true);
    }
  };

  const handleRestart = () => {
    setActiveQuiz(null);
    setSelected(null);
    setAnswers([]);
    setShowResult(false);
    setCurrentIndex(0);
  };

  // Result view
  if (showResult && activeQuiz) {
    const score = activeQuiz.reduce((acc, q, i) => acc + (answers[i] === q.correctIndex ? 1 : 0), 0);
    const percentage = Math.round((score / activeQuiz.length) * 100);

    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
          <div className={`inline-flex p-4 rounded-2xl mb-4 ${percentage >= 50 ? 'bg-green-50' : 'bg-red-50'}`}>
            <Trophy className={`w-12 h-12 ${percentage >= 50 ? 'text-green-600' : 'text-red-500'}`} />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">نتيجة الامتحان</h2>
          <p className="text-slate-500 mb-6">
            أجبت بشكل صحيح على {score} من {activeQuiz.length} أسئلة
          </p>

          {/* Score circle */}
          <div className="inline-flex items-center justify-center w-32 h-32 rounded-full border-8 mb-6"
            style={{ borderColor: percentage >= 50 ? '#16a34a' : '#dc2626' }}
          >
            <span className="text-3xl font-extrabold" style={{ color: percentage >= 50 ? '#16a34a' : '#dc2626' }}>
              {percentage}%
            </span>
          </div>

          {/* Review */}
          <div className="text-right space-y-3 mb-6">
            {activeQuiz.map((q, i) => (
              <div key={q.id} className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 border border-slate-100">
                {answers[i] === q.correctIndex ? (
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-700 font-medium">{q.question}</p>
                  <p className="text-xs text-green-600 mt-1">
                    الإجابة الصحيحة: {q.choices[q.correctIndex]}
                  </p>
                  {answers[i] !== q.correctIndex && (
                    <p className="text-xs text-red-400">
                      إجابتك: {q.choices[answers[i]]}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={handleRestart}
            className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold px-6 py-3 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg mx-auto"
          >
            <RotateCcw className="w-5 h-5" />
            العودة للامتحانات
          </button>
        </div>
      </div>
    );
  }

  // Active quiz view
  if (activeQuiz) {
    const q = activeQuiz[currentIndex];
    const isCorrect = selected === q.correctIndex;

    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
        {/* Progress */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={handleRestart} className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 transition">
            <ChevronLeft className="w-4 h-4" />
            خروج
          </button>
          <span className="text-sm font-medium text-slate-600">
            السؤال {currentIndex + 1} من {activeQuiz.length}
          </span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-2 mb-8">
          <div
            className="bg-gradient-to-r from-cyan-600 to-blue-700 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex) / activeQuiz.length) * 100}%` }}
          />
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-8">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full font-medium">{q.subject}</span>
            <span className={`text-xs px-3 py-1 rounded-full font-medium ${difficultyColors[q.difficulty]}`}>{q.difficulty}</span>
            <button
              onClick={() => {
                setReportTarget({ targetType: 'سؤال', targetTitle: q.question });
                setReportOpen(true);
              }}
              className="mr-auto flex items-center gap-1 text-xs text-amber-600 hover:text-amber-700 hover:bg-amber-50 px-2.5 py-1 rounded-full transition font-medium"
            >
              <Flag className="w-3.5 h-3.5" />
              إبلاغ عن خطأ
            </button>
          </div>

          <h2 className="text-xl font-bold text-slate-800 mb-6 leading-relaxed">{q.question}</h2>

          <div className="space-y-3">
            {q.choices.map((choice, i) => {
              let style = 'border-slate-200 hover:border-cyan-300 hover:bg-cyan-50';
              if (selected !== null) {
                if (i === q.correctIndex) {
                  style = 'border-green-500 bg-green-50';
                } else if (i === selected) {
                  style = 'border-red-400 bg-red-50';
                } else {
                  style = 'border-slate-200 opacity-60';
                }
              }
              return (
                <button
                  key={i}
                  onClick={() => handleSelect(i)}
                  disabled={selected !== null}
                  className={`w-full text-right flex items-center gap-3 p-4 rounded-xl border-2 transition-all ${style}`}
                >
                  <span className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition ${
                    selected !== null && i === q.correctIndex
                      ? 'bg-green-500 text-white'
                      : selected !== null && i === selected
                      ? 'bg-red-500 text-white'
                      : 'bg-slate-100 text-slate-600'
                  }`}>
                    {selected !== null && i === q.correctIndex ? <CheckCircle2 className="w-4 h-4" /> :
                     selected !== null && i === selected ? <XCircle className="w-4 h-4" /> :
                     labels[i]}
                  </span>
                  <span className="text-slate-700 font-medium">{choice}</span>
                </button>
              );
            })}
          </div>

          {selected !== null && (
            <div className="mt-6 animate-fade-in-up">
              <div className={`flex items-center gap-2 rounded-lg px-4 py-3 mb-4 ${isCorrect ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
                {isCorrect ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                <span className="text-sm font-medium">
                  {isCorrect ? 'إجابة صحيحة!' : `إجابة خاطئة - الصحيح: ${q.choices[q.correctIndex]}`}
                </span>
              </div>
              <button
                onClick={handleNext}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold py-3 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg"
              >
                {currentIndex + 1 < activeQuiz.length ? 'السؤال التالي' : 'عرض النتيجة'}
                <ChevronLeft className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Quiz selection view
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-3">مركز الامتحانات</h1>
        <p className="text-slate-500">حل امتحانات تفاعلية واحصل على نتيجتك فوراً</p>
      </div>

      <AdSlot slot="header" />

      {questions.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <AlertCircle className="w-12 h-12 text-slate-300 mb-4" />
          <p className="text-slate-400">لا توجد أسئلة متاحة حالياً</p>
        </div>
      ) : (
        <>
          {/* All questions quiz */}
          <div className="mt-8 mb-6">
            <button
              onClick={startAllQuiz}
              className="w-full flex items-center justify-between gap-4 bg-gradient-to-r from-cyan-600 to-blue-700 text-white p-6 rounded-2xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg group"
            >
              <div className="flex items-center gap-4">
                <div className="bg-white/20 p-3 rounded-xl">
                  <ClipboardCheck className="w-8 h-8" />
                </div>
                <div className="text-right">
                  <h3 className="font-bold text-lg">امتحان شامل (جميع المواد)</h3>
                  <p className="text-sm text-blue-100">{questions.length} سؤال متنوع</p>
                </div>
              </div>
              <Play className="w-6 h-6 group-hover:scale-110 transition" />
            </button>
          </div>

          {/* Per subject quizzes */}
          <h2 className="text-xl font-bold text-slate-700 mb-4">امتحانات حسب المادة</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {subjectsWithQuestions.map((subject) => {
              const count = questions.filter((q) => q.subject === subject).length;
              return (
                <div
                  key={subject}
                  className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-xl transition-all hover:-translate-y-1 group"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="bg-cyan-50 p-3 rounded-xl">
                      <ClipboardCheck className="w-7 h-7 text-cyan-600" />
                    </div>
                    <span className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full font-medium">
                      {count} سؤال
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-800 mb-4">{subject}</h3>
                  <button
                    onClick={() => startQuiz(subject)}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold py-2.5 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition group-hover:shadow-lg"
                  >
                    <Play className="w-4 h-4" />
                    ابدأ الامتحان
                  </button>
                </div>
              );
            })}
          </div>
        </>
      )}

      <div className="mt-8">
        <AdSlot slot="belowContent" />
      </div>

      <ReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        targetType={reportTarget.targetType}
        targetTitle={reportTarget.targetTitle}
      />
    </div>
  );
}
