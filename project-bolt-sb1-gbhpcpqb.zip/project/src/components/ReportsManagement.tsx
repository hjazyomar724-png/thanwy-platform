import { useState } from 'react';
import {
  Flag, CheckCircle2, Trash2, Clock, Inbox,
} from 'lucide-react';
import { useContent } from '@/context/ContentContext';

export default function ReportsManagement() {
  const { reports, resolveReport, deleteReport } = useContent();
  const [filter, setFilter] = useState<'الكل' | 'جديد' | 'تم المراجعة'>('الكل');

  const filtered = reports.filter((r) => filter === 'الكل' || r.status === filter);
  const newCount = reports.filter((r) => r.status === 'جديد').length;

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-3">
          <div className="bg-slate-100 p-3 rounded-xl">
            <Flag className="w-6 h-6 text-slate-600" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-800">{reports.length}</div>
            <div className="text-xs text-slate-500">إجمالي البلاغات</div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-3">
          <div className="bg-amber-50 p-3 rounded-xl">
            <Clock className="w-6 h-6 text-amber-600" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-amber-600">{newCount}</div>
            <div className="text-xs text-slate-500">بلاغات جديدة</div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-3">
          <div className="bg-green-50 p-3 rounded-xl">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-green-600">{reports.length - newCount}</div>
            <div className="text-xs text-slate-500">تمت المراجعة</div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {(['الكل', 'جديد', 'تم المراجعة'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
              filter === f ? 'bg-cyan-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Reports list */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Inbox className="w-12 h-12 text-slate-300 mb-4" />
          <p className="text-slate-400">لا توجد بلاغات {filter !== 'الكل' ? filter : ''}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((report) => (
            <div
              key={report.id}
              className={`bg-white rounded-xl border p-5 transition ${
                report.status === 'جديد' ? 'border-amber-200' : 'border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs px-2.5 py-0.5 rounded-full font-medium ${
                      report.status === 'جديد'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-green-100 text-green-700'
                    }`}>
                      {report.status}
                    </span>
                    <span className="text-xs bg-slate-100 text-slate-500 px-2.5 py-0.5 rounded-full">
                      {report.targetType}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-slate-700 truncate">
                    {report.targetTitle}
                  </p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {report.status === 'جديد' && (
                    <button
                      onClick={() => resolveReport(report.id)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-50 text-green-600 hover:bg-green-100 transition text-xs font-medium"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      مراجعة
                    </button>
                  )}
                  <button
                    onClick={() => deleteReport(report.id)}
                    className="p-1.5 rounded-lg text-red-400 hover:bg-red-50 hover:text-red-600 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <p className="text-sm text-slate-600 bg-slate-50 rounded-lg p-3 leading-relaxed mb-2">
                {report.message}
              </p>

              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>من: {report.studentName}</span>
                <span>{formatDate(report.createdAt)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
