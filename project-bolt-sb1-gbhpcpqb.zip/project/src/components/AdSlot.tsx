import { useSettings } from '@/context/SettingsContext';

interface AdSlotProps {
  slot: 'header' | 'sidebar' | 'belowContent';
  className?: string;
}

export default function AdSlot({ slot, className = '' }: AdSlotProps) {
  const { settings } = useSettings();

  const code = settings.adCodes[slot];

  if (!settings.adsEnabled || !code.trim()) {
    return null;
  }

  return (
    <div
      className={`ad-slot ${className}`}
      dangerouslySetInnerHTML={{ __html: code }}
    />
  );
}
