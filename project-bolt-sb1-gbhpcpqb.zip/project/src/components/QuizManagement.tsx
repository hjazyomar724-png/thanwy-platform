import { useState } from 'react';
import { Plus, Trash2, ClipboardList, CheckCircle2, Pencil, X, Save } from 'lucide-react';
import { useContent } from '@/context/ContentContext';
import { subjects } from '@/data';
import type { QuizQuestion } from '@/types';

const difficultyOptions: QuizQuestion['difficulty'][] = ['سهل', 'متوسط', 'صعب'];

const emptyForm = {
  subject: subjects[0].name,
  question: '',
  a: '', b: '', c: '', d: '',
  correct: '0' as '0' | '1' | '2' | '3',
  difficulty: 'متوسط' as QuizQuestion['difficulty'],
};

const labels = ['A', 'B', 'C', 'D'];
const choiceFields = ['a', 'b', 'c', 'd'] as const;

export default function QuizManagement() {
  const { questions, addQuestion, updateQuestion, deleteQuestion } = useContent();
  const [form, setForm] = useState({ ...emptyForm });
  const [added, setAdded] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<typeof emptyForm | null>(null);
  const [savedEdit, setSavedEdit] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.question.trim() || !form.a.trim() || !form.b.trim() || !form.c.trim() || !form.d.trim()) return;

    addQuestion({
      id: `q-${Date.now()}`,
      subject: form.subject,
      question: form.question,
      choices: [form.a, form.b, form.c, form.d],
      correctIndex: parseInt(form.correct, 10),
      difficulty: form.difficulty,
    });

    setForm({ ...emptyForm });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const startEdit = (q: QuizQuestion) => {
    setEditingId(q.id);
    setEditForm({
      subject: q.subject,
      question: q.question,
      a: q.choices[0],
      b: q.choices[1],
      c: q.choices[2],
      d: q.choices[3],
      correct: String(q.correctIndex) as '0' | '1' | '2' | '3',
      difficulty: q.difficulty,
    });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm(null);
  };

  const saveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm || !editingId) return;
    if (!editForm.question.trim() || !editForm.a.trim() || !editForm.b.trim() || !editForm.c.trim() || !editForm.d.trim()) return;

    updateQuestion({
      id: editingId,
      subject: editForm.subject,
      question: editForm.question,
      choices: [editForm.a, editForm.b, editForm.c, editForm.d],
      correctIndex: parseInt(editForm.correct, 10),
      difficulty: editForm.difficulty,
    });

    cancelEdit();
    setSavedEdit(true);
    setTimeout(() => setSavedEdit(false), 2000);
  };

  return (
    <div className="space-y-6">
      {added && (
        <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg px-4 py-3 animate-fade-in-up">
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-medium">تمت إضافة السؤال بنجاح! يظهر الآن في مركز الامتحانات.</span>
        </div>
      )}

      {savedEdit && (
        <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg px-4 py-3 animate-fade-in-up">
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-medium">تم حفظ التعديلات بنجاح! تم تحديث السؤال في بنك الأسئلة.</span>
        </div>
      )}

      {/* Add form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Plus className="w-5 h-5 text-cyan-600" />
          <h3 className="font-bold text-slate-800">إضافة سؤال جديد</h3>
        </div>

        {/* Subject + difficulty */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">المادة</label>
            <select
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.name}>{s.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">مستوى الصعوبة</label>
            <select
              value={form.difficulty}
              onChange={(e) => setForm({ ...form, difficulty: e.target.value as QuizQuestion['difficulty'] })}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
            >
              {difficultyOptions.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Question */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">نص السؤال</label>
          <textarea
            value={form.question}
            onChange={(e) => setForm({ ...form, question: e.target.value })}
            rows={2}
            placeholder="اكتب السؤال هنا..."
            className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800 resize-none"
          />
        </div>

        {/* Choices */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {choiceFields.map((field, i) => (
            <div key={field}>
              <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1">
                <span className="bg-slate-100 text-slate-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">
                  {labels[i]}
                </span>
                الاختيار {labels[i]}
              </label>
              <input
                type="text"
                value={form[field]}
                onChange={(e) => setForm({ ...form, [field]: e.target.value })}
                placeholder={`الاختيار ${labels[i]}`}
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-slate-800"
              />
            </div>
          ))}
        </div>

        {/* Correct answer */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">الإجابة الصحيحة</label>
          <div className="flex gap-2">
            {labels.map((label, i) => (
              <button
                key={label}
                type="button"
                onClick={() => setForm({ ...form, correct: String(i) as '0' | '1' | '2' | '3' })}
                className={`px-4 py-2 rounded-lg text-sm font-bold transition border-2 ${
                  form.correct === String(i)
                    ? 'bg-green-500 text-white border-green-500'
                    : 'bg-white text-slate-600 border-slate-300 hover:border-slate-400'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold px-6 py-3 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg"
        >
          <Plus className="w-5 h-5" />
          إضافة السؤال
        </button>
      </form>

      {/* Existing questions */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <ClipboardList className="w-5 h-5 text-slate-600" />
          <h3 className="font-bold text-slate-800">الأسئلة المضافة ({questions.length})</h3>
        </div>
        {questions.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-6">لا توجد أسئلة بعد</p>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {questions.map((q, i) => (
              <div key={q.id} className="rounded-lg bg-slate-50 border border-slate-100 overflow-hidden">
                {/* Question row */}
                <div className="flex items-start gap-3 p-3">
                  <span className="flex-shrink-0 w-7 h-7 bg-cyan-100 text-cyan-700 rounded-full flex items-center justify-center text-xs font-bold">
                    {i + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full">{q.subject}</span>
                      <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">{q.difficulty}</span>
                    </div>
                    <p className="text-sm text-slate-700 font-medium">{q.question}</p>
                    <p className="text-xs text-green-600 mt-1">
                      الإجابة: {q.choices[q.correctIndex]}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={() => startEdit(q)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-cyan-600 hover:bg-cyan-50 transition text-xs font-medium"
                    >
                      <Pencil className="w-4 h-4" />
                      تعديل
                    </button>
                    <button
                      onClick={() => deleteQuestion(q.id)}
                      className="flex-shrink-0 p-1.5 rounded-lg text-red-400 hover:bg-red-50 hover:text-red-600 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Inline edit form */}
                {editingId === q.id && editForm && (
                  <form
                    onSubmit={saveEdit}
                    className="border-t border-slate-200 bg-white p-4 space-y-3 animate-fade-in-up"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-bold text-slate-700">تعديل السؤال</span>
                      <button
                        type="button"
                        onClick={cancelEdit}
                        className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 transition"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <select
                        value={editForm.subject}
                        onChange={(e) => setEditForm({ ...editForm, subject: e.target.value })}
                        className="px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                      >
                        {subjects.map((s) => (
                          <option key={s.id} value={s.name}>{s.name}</option>
                        ))}
                      </select>
                      <select
                        value={editForm.difficulty}
                        onChange={(e) => setEditForm({ ...editForm, difficulty: e.target.value as QuizQuestion['difficulty'] })}
                        className="px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                      >
                        {difficultyOptions.map((d) => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>

                    <textarea
                      value={editForm.question}
                      onChange={(e) => setEditForm({ ...editForm, question: e.target.value })}
                      rows={2}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800 resize-none"
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {choiceFields.map((field, idx) => (
                        <div key={field} className="flex items-center gap-2">
                          <span className="bg-slate-100 text-slate-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                            {labels[idx]}
                          </span>
                          <input
                            type="text"
                            value={editForm[field]}
                            onChange={(e) => setEditForm({ ...editForm, [field]: e.target.value })}
                            className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200 outline-none transition text-sm text-slate-800"
                          />
                        </div>
                      ))}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1.5">الإجابة الصحيحة</label>
                      <div className="flex gap-2">
                        {labels.map((label, i) => (
                          <button
                            key={label}
                            type="button"
                            onClick={() => setEditForm({ ...editForm, correct: String(i) as '0' | '1' | '2' | '3' })}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition border-2 ${
                              editForm.correct === String(i)
                                ? 'bg-green-500 text-white border-green-500'
                                : 'bg-white text-slate-600 border-slate-300 hover:border-slate-400'
                            }`}
                          >
                            {label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-700 text-white font-bold px-5 py-2.5 rounded-xl hover:from-cyan-700 hover:to-blue-800 transition shadow-lg text-sm"
                    >
                      <Save className="w-4 h-4" />
                      حفظ التعديلات
                    </button>
                  </form>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
