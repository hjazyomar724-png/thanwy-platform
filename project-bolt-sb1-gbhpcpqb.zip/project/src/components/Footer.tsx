import { GraduationCap, Code2, Phone, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-2 rounded-xl">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="text-lg font-bold text-white">منصة الطالب المصري</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              منصة تعليمية متكاملة لطلاب الثانوية العامة في مصر، تقدم ملخصات وامتحانات وأدوات مذاكرة مجانية.
            </p>
          </div>

          {/* Quick links */}
          <div className="flex flex-col gap-2">
            <h3 className="text-white font-bold mb-2">روابط سريعة</h3>
            <span className="text-sm text-slate-400 hover:text-cyan-400 transition cursor-pointer">المواد الدراسية</span>
            <span className="text-sm text-slate-400 hover:text-cyan-400 transition cursor-pointer">الامتحانات</span>
            <span className="text-sm text-slate-400 hover:text-cyan-400 transition cursor-pointer">جدول المذاكرة</span>
            <span className="text-sm text-slate-400 hover:text-cyan-400 transition cursor-pointer">من نحن</span>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-2">
            <h3 className="text-white font-bold mb-2">تواصل معنا</h3>
            <a href="tel:01099741582" className="flex items-center gap-2 text-sm text-slate-400 hover:text-cyan-400 transition">
              <Phone className="w-4 h-4" />
              <span dir="ltr">01099741582</span>
            </a>
            <a href="mailto:hjazyomar724@gmail.com" className="flex items-center gap-2 text-sm text-slate-400 hover:text-cyan-400 transition">
              <Mail className="w-4 h-4" />
              <span dir="ltr">hjazyomar724@gmail.com</span>
            </a>
          </div>
        </div>

        {/* Developer credit */}
        <div className="border-t border-slate-700 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-sm text-slate-400">
            © 2026 منصة الطالب المصري - جميع الحقوق محفوظة
          </p>
          <div className="flex items-center gap-2 text-sm">
            <Code2 className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-300 font-medium">
              تطوير بواسطة المهندس عمر حجازي
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300 font-medium">
              Developed by Omar Hegazy
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
