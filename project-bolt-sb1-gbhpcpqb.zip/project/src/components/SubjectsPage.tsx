import {
  BookOpen, Globe, Sigma, Atom, FlaskConical, Dna, ScrollText, MapPinned,
  Brain, HeartHandshake, ArrowRight, type LucideIcon,
} from 'lucide-react';
import { subjects } from '@/data';
import AdSlot from '@/components/AdSlot';

const iconMap: Record<string, LucideIcon> = {
  BookOpen, Globe, Sigma, Atom, FlaskConical, Dna, ScrollText, MapPinned,
  Brain, HeartHandshake,
};

export default function SubjectsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in-up">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-3">المواد الدراسية</h1>
        <p className="text-slate-500">تصفح مواد الثانوية العامة وابدأ المذاكرة</p>
      </div>

      <AdSlot slot="header" />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {subjects.map((subject) => {
          const Icon = iconMap[subject.icon];
          return (
            <div
              key={subject.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1 cursor-pointer group"
            >
              <div
                className="h-2"
                style={{ backgroundColor: subject.color }}
              />
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="p-3 rounded-xl group-hover:scale-110 transition"
                    style={{ backgroundColor: subject.color + '15' }}
                  >
                    {Icon && <Icon className="w-8 h-8" style={{ color: subject.color }} />}
                  </div>
                  <span className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full font-medium">
                    {subject.lessons} درس
                  </span>
                </div>
                <h3 className="font-bold text-lg text-slate-800 mb-1">{subject.name}</h3>
                <p className="text-sm text-slate-500 mb-4">{subject.description}</p>
                <button
                  className="flex items-center gap-1 text-sm font-medium transition group-hover:gap-2"
                  style={{ color: subject.color }}
                >
                  ابدأ المذاكرة
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8">
        <AdSlot slot="belowContent" />
      </div>
    </div>
  );
}
