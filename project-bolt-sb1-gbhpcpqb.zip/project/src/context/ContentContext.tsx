import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import type { QuizQuestion, LibraryBook, ErrorReport, Post, Comment } from '@/types';
import {
  loadQuestions, saveQuestions,
  loadBooks, saveBooks,
  loadReports, saveReports,
  loadPosts, savePosts,
} from '@/contentStore';

interface ContentContextValue {
  questions: QuizQuestion[];
  addQuestion: (q: QuizQuestion) => void;
  updateQuestion: (q: QuizQuestion) => void;
  deleteQuestion: (id: string) => void;
  books: LibraryBook[];
  addBook: (b: LibraryBook) => void;
  updateBook: (b: LibraryBook) => void;
  deleteBook: (id: string) => void;
  reports: ErrorReport[];
  addReport: (r: ErrorReport) => void;
  resolveReport: (id: string) => void;
  deleteReport: (id: string) => void;
  posts: Post[];
  addPost: (p: Post) => void;
  updatePost: (p: Post) => void;
  deletePost: (id: string) => void;
  toggleLike: (id: string) => void;
  addComment: (id: string, c: Comment) => void;
}

const ContentContext = createContext<ContentContextValue | null>(null);

export function ContentProvider({ children }: { children: ReactNode }) {
  const [questions, setQuestions] = useState<QuizQuestion[]>(() => loadQuestions());
  const [books, setBooks] = useState<LibraryBook[]>(() => loadBooks());
  const [reports, setReports] = useState<ErrorReport[]>(() => loadReports());
  const [posts, setPosts] = useState<Post[]>(() => loadPosts());

  useEffect(() => { saveQuestions(questions); }, [questions]);
  useEffect(() => { saveBooks(books); }, [books]);
  useEffect(() => { saveReports(reports); }, [reports]);
  useEffect(() => { savePosts(posts); }, [posts]);

  const addQuestion = (q: QuizQuestion) => setQuestions((prev) => [...prev, q]);
  const updateQuestion = (q: QuizQuestion) =>
    setQuestions((prev) => prev.map((item) => (item.id === q.id ? q : item)));
  const deleteQuestion = (id: string) => setQuestions((prev) => prev.filter((q) => q.id !== id));
  const addBook = (b: LibraryBook) => setBooks((prev) => [...prev, b]);
  const updateBook = (b: LibraryBook) =>
    setBooks((prev) => prev.map((item) => (item.id === b.id ? b : item)));
  const deleteBook = (id: string) => setBooks((prev) => prev.filter((b) => b.id !== id));
  const addReport = (r: ErrorReport) => setReports((prev) => [r, ...prev]);
  const resolveReport = (id: string) =>
    setReports((prev) => prev.map((r) => (r.id === id ? { ...r, status: 'تم المراجعة' } : r)));
  const deleteReport = (id: string) => setReports((prev) => prev.filter((r) => r.id !== id));

  const addPost = (p: Post) => setPosts((prev) => [p, ...prev]);
  const updatePost = (p: Post) =>
    setPosts((prev) => prev.map((item) => (item.id === p.id ? p : item)));
  const deletePost = (id: string) => setPosts((prev) => prev.filter((p) => p.id !== id));
  const toggleLike = (id: string) =>
    setPosts((prev) => prev.map((p) =>
      p.id === id ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 } : p
    ));
  const addComment = (id: string, c: Comment) =>
    setPosts((prev) => prev.map((p) =>
      p.id === id ? { ...p, comments: [...p.comments, c] } : p
    ));

  return (
    <ContentContext.Provider
      value={{
        questions, addQuestion, updateQuestion, deleteQuestion,
        books, addBook, updateBook, deleteBook,
        reports, addReport, resolveReport, deleteReport,
        posts, addPost, updatePost, deletePost, toggleLike, addComment,
      }}
    >
      {children}
    </ContentContext.Provider>
  );
}

export function useContent(): ContentContextValue {
  const ctx = useContext(ContentContext);
  if (!ctx) throw new Error('useContent must be used within ContentProvider');
  return ctx;
}
