import {
  DEFAULT_SETTINGS,
  type AdminSettings,
} from '@/types';

const STORAGE_KEY = 'admin_settings_v1';

export function loadSettings(): AdminSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AdminSettings>;
    return {
      adsEnabled: parsed.adsEnabled ?? DEFAULT_SETTINGS.adsEnabled,
      adCodes: {
        header: parsed.adCodes?.header ?? '',
        sidebar: parsed.adCodes?.sidebar ?? '',
        belowContent: parsed.adCodes?.belowContent ?? '',
      },
      seasonalTheme: parsed.seasonalTheme ?? DEFAULT_SETTINGS.seasonalTheme,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AdminSettings): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
}
