import type { QuizQuestion, LibraryBook, ErrorReport, Post } from '@/types';

const QUIZ_KEY = 'quiz_questions_v1';
const LIBRARY_KEY = 'library_books_v1';
const REPORTS_KEY = 'error_reports_v1';
const POSTS_KEY = 'posts_v1';

export const seedQuestions: QuizQuestion[] = [
  {
    id: 'q-seed-1',
    subject: 'الفيزياء',
    question: 'جسم كتلته 2 كجم يتحرك بسرعة 10 م/ث، ما طاقة حركته؟',
    choices: ['100 جول', '50 جول', '200 جول', '20 جول'],
    correctIndex: 0,
    difficulty: 'متوسط',
  },
  {
    id: 'q-seed-2',
    subject: 'الكيمياء',
    question: 'ما هو الرقم الذري لعنصر الصوديوم (Na)؟',
    choices: ['12', '11', '10', '13'],
    correctIndex: 1,
    difficulty: 'سهل',
  },
  {
    id: 'q-seed-3',
    subject: 'اللغة العربية',
    question: '"الطالبُ مجتهدٌ" — ما إعراب كلمة "مجتهدٌ"؟',
    choices: ['مبتدأ', 'خبر المبتدأ', 'نعت', 'حال'],
    correctIndex: 1,
    difficulty: 'سهل',
  },
  {
    id: 'q-seed-4',
    subject: 'الفيزياء',
    question: 'وحدة قياس شدة التيار الكهربي هي:',
    choices: ['الفولت', 'الأوم', 'الأمبير', 'الواط'],
    correctIndex: 2,
    difficulty: 'سهل',
  },
  {
    id: 'q-seed-5',
    subject: 'الكيمياء',
    question: 'أي من التالي يعتبر من الغازات النبيلة؟',
    choices: ['الأكسجين', 'النيتروجين', 'الأرجون', 'الهيدروجين'],
    correctIndex: 2,
    difficulty: 'متوسط',
  },
];

export const seedBooks: LibraryBook[] = [
  { id: 'b-seed-1', title: 'كتاب مفاهيم الفيزياء 2026', subject: 'الفيزياء', type: 'مفاهيم', link: '#' },
  { id: 'b-seed-2', title: 'ملخص النحو الوافي', subject: 'اللغة العربية', type: 'ملخص', link: '#' },
  { id: 'b-seed-3', title: 'كتاب الوزارة للكيمياء العضوية', subject: 'الكيمياء', type: 'كتاب وزارة', link: '#' },
  { id: 'b-seed-4', title: 'ملخص البلاغة والنصوص', subject: 'اللغة العربية', type: 'ملخص', link: '#' },
  { id: 'b-seed-5', title: 'مفاهيم الأحياء الشاملة', subject: 'الأحياء', type: 'مفاهيم', link: '#' },
  { id: 'b-seed-6', title: 'كتاب الوزارة للرياضيات - الجبر', subject: 'الرياضيات', type: 'كتاب وزارة', link: '#' },
  { id: 'b-seed-7', title: 'ملخص التاريخ المصري الحديث', subject: 'التاريخ', type: 'ملخص', link: '#' },
  { id: 'b-seed-8', title: 'مفاهيم الفلسفة والمنطق', subject: 'الفلسفة والمنطق', type: 'مفاهيم', link: '#' },
];

export function loadQuestions(): QuizQuestion[] {
  try {
    const raw = localStorage.getItem(QUIZ_KEY);
    if (!raw) return seedQuestions;
    return JSON.parse(raw) as QuizQuestion[];
  } catch {
    return seedQuestions;
  }
}

export function saveQuestions(questions: QuizQuestion[]): void {
  localStorage.setItem(QUIZ_KEY, JSON.stringify(questions));
}

export function loadBooks(): LibraryBook[] {
  try {
    const raw = localStorage.getItem(LIBRARY_KEY);
    if (!raw) return seedBooks;
    return JSON.parse(raw) as LibraryBook[];
  } catch {
    return seedBooks;
  }
}

export function saveBooks(books: LibraryBook[]): void {
  localStorage.setItem(LIBRARY_KEY, JSON.stringify(books));
}

export function loadReports(): ErrorReport[] {
  try {
    const raw = localStorage.getItem(REPORTS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as ErrorReport[];
  } catch {
    return [];
  }
}

export function saveReports(reports: ErrorReport[]): void {
  localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
}

export const seedPosts: Post[] = [
  {
    id: 'p-seed-1',
    title: 'جدول امتحانات الشهر التجريبية',
    content: 'تم تحديد جدول الامتحانات التجريبية لشهر أكتوبر. يبدأ الامتحان يوم السبت الموافق 18 أكتوبر بمادة اللغة العربية، يليه الرياضيات يوم الأحد. ننصح جميع الطلاب بمراجعة جدول المذاكرة والاستعداد مبكراً. بالتوفيق للجميع!',
    author: 'إدارة المنصة',
    createdAt: Date.now() - 86400000,
    likes: 12,
    liked: false,
    comments: [
      { id: 'c-1', author: 'أحمد', text: 'شكراً على التحديث، هل الامتحان شامل لكل المنهج؟', createdAt: Date.now() - 80000000 },
    ],
  },
  {
    id: 'p-seed-2',
    title: 'نصائح هامة للمذاكرة بتركيز',
    content: '1. خصص مكاناً هادئاً للمذاكرة بعيداً عن المشتتات.\n2. استخدم تقنية بومودورو: 25 دقيقة مذاكرة ثم 5 دقائق راحة.\n3. اكتب ملخصات بخط يدك لتثبيت المعلومات.\n4. حُل أسئلة كثيرة بعد كل درس.\n5. نم 7-8 ساعات يومياً لنشاط الدماغ.',
    author: 'إدارة المنصة',
    createdAt: Date.now() - 172800000,
    likes: 25,
    liked: false,
    comments: [],
  },
  {
    id: 'p-seed-3',
    title: 'تم إضافة كتب ومفاهيم جديدة لمادة الفيزياء',
    content: 'يسعدنا إعلامكم بإضافة كتاب مفاهيم الفيزياء 2026 الجديد إلى مركز الملخصات. الكتاب شامل لجميع أبواب المنهج مع أمثلة محلولة وتمارين متنوعة. يمكنكم تصفحه وتحميله الآن من صفحة مركز الملخصات.',
    author: 'إدارة المنصة',
    createdAt: Date.now() - 259200000,
    likes: 8,
    liked: false,
    comments: [],
  },
];

export function loadPosts(): Post[] {
  try {
    const raw = localStorage.getItem(POSTS_KEY);
    if (!raw) return seedPosts;
    return JSON.parse(raw) as Post[];
  } catch {
    return seedPosts;
  }
}

export function savePosts(posts: Post[]): void {
  localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
}
