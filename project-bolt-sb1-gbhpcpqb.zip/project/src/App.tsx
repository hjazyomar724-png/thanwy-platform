import { useState } from 'react';
import { SettingsProvider, useSettings } from '@/context/SettingsContext';
import { ContentProvider } from '@/context/ContentContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HomePage from '@/components/HomePage';
import SubjectsPage from '@/components/SubjectsPage';
import ExamsPage from '@/components/ExamsPage';
import SchedulePage from '@/components/SchedulePage';
import AboutPage from '@/components/AboutPage';
import StudyHubPage from '@/components/StudyHubPage';
import CommunityFeedPage from '@/components/CommunityFeedPage';
import AIChatPage from '@/components/AIChatPage';
import AdminGate from '@/components/AdminGate';
import AdminPanel from '@/components/AdminPanel';
import SeasonalDecorations from '@/components/SeasonalDecorations';
import type { ThemeKey } from '@/types';

function AppContent() {
  const { settings } = useSettings();
  const [currentPage, setCurrentPage] = useState('home');
  const [adminAuthed, setAdminAuthed] = useState(false);

  const themeClass: ThemeKey = settings.seasonalTheme;
  const isRamadan = themeClass === 'ramadan';

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    if (currentPage === 'admin') {
      if (!adminAuthed) {
        return <AdminGate onSuccess={() => setAdminAuthed(true)} />;
      }
      return <AdminPanel onLogout={() => setAdminAuthed(false)} />;
    }

    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'subjects':
        return <SubjectsPage />;
      case 'studyhub':
        return <StudyHubPage />;
      case 'feed':
        return <CommunityFeedPage />;
      case 'ai':
        return <AIChatPage />;
      case 'exams':
        return <ExamsPage />;
      case 'schedule':
        return <SchedulePage />;
      case 'about':
        return <AboutPage />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className={`theme-${themeClass} min-h-screen flex flex-col`}>
      <SeasonalDecorations />
      <div className={isRamadan ? 'relative z-40 flex flex-col flex-1' : 'flex flex-col flex-1'}>
        <Header onNavigate={handleNavigate} currentPage={currentPage} />
        <main className={`flex-1 ${isRamadan ? 'text-slate-100' : ''}`}>
          {renderPage()}
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <ContentProvider>
        <AppContent />
      </ContentProvider>
    </SettingsProvider>
  );
}
